package com.example.hafizmnawaz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
