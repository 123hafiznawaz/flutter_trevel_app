import 'package:flutter/material.dart';
// Assuming you might want to use 'Inter' or 'Roboto' fonts.
// Make sure they are included in your pubspec.yaml if you use them explicitly.
// For example, using google_fonts package:
// import 'package:google_fonts/google_fonts.dart';

class TransportTypeWidget extends StatefulWidget {
  @override
  _TransportTypeWidgetState createState() => _TransportTypeWidgetState();
}

class _TransportTypeWidgetState extends State<TransportTypeWidget> {
  // --- Theme Colors ---
  final Color _primaryGreen = Color(0xFF2E7D32); // A deep, professional green
  final Color _lightGreenAccent = Color(0xFFC8E6C9); // Light green for accents/borders
  final Color _whiteColor = Colors.white;
  final Color _textColorOnPrimary = Colors.white;
  final Color _textColorOnWhite = Color(0xFF1C1B1F); // Dark grey, from original: Color.fromRGBO(28, 27, 31, 1)
  final Color _iconColorGreen = Color(0xFF2E7D32);
  final Color _iconColorOnWhite = Color(0xFF49454F); // Slightly lighter grey for icons on white
  final Color _neutralBorderColor = Colors.grey[300]!;

  // --- State ---
  String? _selectedTransport; // To keep track of the selected transport type

  // --- Font Styles ---
  TextStyle get _titleTextStyle => TextStyle(
      color: _primaryGreen,
      fontFamily: 'Inter', // Fallback to system if not found
      fontSize: 28,
      fontWeight: FontWeight.bold,
      height: 1.25);

  TextStyle get _bodyTextStyle => TextStyle(
      fontFamily: 'Inter', // Fallback to system if not found
      fontSize: 16,
      color: _textColorOnWhite,
      height: 1.375);

  TextStyle get _buttonTextStyle => TextStyle(
      fontFamily: 'Inter', // Fallback to system if not found
      fontSize: 18,
      fontWeight: FontWeight.w500);

  TextStyle get _statusBarTextStyle => TextStyle(
      color: _textColorOnWhite,
      fontFamily: 'Roboto', // As in original
      fontSize: 14,
      fontWeight: FontWeight.normal);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _whiteColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch, // Make children take full width
                    children: <Widget>[
                      _buildStatusBar(context),
                      SizedBox(height: 24.000030517578125 - 12), // Adjusted for SafeArea and top padding
                      _buildTitle(),
                      SizedBox(height: 24.0), // Spacing after title
                      _buildAccessoryIconsRow(context),
                      SizedBox(height: 24.0), // Spacing before transport options
                      _buildTransportOptionItem(
                        context,
                        icon: Icons.directions_car_filled,
                        label: 'Car Rental',
                        isSelected: _selectedTransport == 'Car Rental',
                        onTap: () => setState(() => _selectedTransport = 'Car Rental'),
                      ),
                      _buildTransportOptionItem(
                        context,
                        icon: Icons.directions_bus_filled,
                        label: 'Bus',
                        isSelected: _selectedTransport == 'Bus',
                        onTap: () => setState(() => _selectedTransport = 'Bus'),
                      ),
                      _buildTransportOptionItem(
                        context,
                        icon: Icons.local_taxi,
                        label: 'Taxi',
                        isSelected: _selectedTransport == 'Taxi',
                        onTap: () => setState(() => _selectedTransport = 'Taxi'),
                      ),
                      SizedBox(height: 20), // Some padding at the bottom
                      // --- NEW: Next Button ---
                      ElevatedButton(
                        onPressed: _selectedTransport != null
                            ? () {
                          // Navigate to the next screen if a transport type is selected
                          Navigator.pushNamed(context, '/transportbooking');
                        }
                            : null, // Disable button if no transport is selected
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _primaryGreen,
                          foregroundColor: _textColorOnPrimary,
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 3,
                        ),
                        child: Text(
                          'Next',
                          style: _buttonTextStyle.copyWith(
                            color: _textColorOnPrimary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(height: 20), // Padding after the button
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildStatusBar(BuildContext context) {
    // Current time: Tuesday, June 3, 2025 at 11:00:24 PM PKT
    final now = DateTime.now();
    final String formattedTime =
        "${now.hour % 12 == 0 ? 12 : now.hour % 12}:${now.minute.toString().padLeft(2, '0')} ${now.hour >= 12 ? 'PM' : 'AM'}";

    return Padding(
      padding: const EdgeInsets.only(top: 0, bottom: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(formattedTime,
              style: _statusBarTextStyle.copyWith(fontWeight: FontWeight.bold)),
          Row(
            children: <Widget>[
              Icon(Icons.wifi, color: _iconColorOnWhite, size: 20),
              SizedBox(width: 8),
              Icon(Icons.signal_cellular_alt, color: _iconColorOnWhite, size: 20),
              SizedBox(width: 8),
              Icon(Icons.battery_std, color: _iconColorOnWhite, size: 20),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        'Select Transportation Service',
        textAlign: TextAlign.center,
        style: _titleTextStyle,
      ),
    );
  }

  Widget _buildAccessoryIconsRow(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          _buildAccessoryIcon(Icons.settings_outlined, _neutralBorderColor),
          SizedBox(width: 20),
          _buildAccessoryIcon(Icons.info_outline, _neutralBorderColor),
          SizedBox(width: 20),
          _buildAccessoryIcon(Icons.help_outline, _neutralBorderColor),
        ],
      ),
    );
  }

  Widget _buildAccessoryIcon(IconData icon, Color borderColor) {
    return Container(
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _whiteColor,
          border: Border.all(color: borderColor, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 2,
              offset: Offset(0, 1),
            )
          ]
      ),
      child: Icon(icon, color: _iconColorGreen, size: 22),
    );
  }

  Widget _buildTransportOptionItem(
      BuildContext context, {
        required IconData icon,
        required String label,
        required bool isSelected,
        required VoidCallback onTap,
      }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? _primaryGreen : _whiteColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? _primaryGreen : _lightGreenAccent,
            width: 1.5,
          ),
          boxShadow: !isSelected ? [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 4,
              offset: Offset(0, 2),
            )
          ] : [
            BoxShadow(
              color: _primaryGreen.withOpacity(0.3),
              spreadRadius: 1,
              blurRadius: 4,
              offset: Offset(0, 2),
            )
          ],
        ),
        child: Row(
          children: <Widget>[
            Icon(
              icon,
              color: isSelected ? _textColorOnPrimary : _iconColorGreen,
              size: 26,
            ),
            SizedBox(width: 16),
            Expanded(
              child: Text(
                label,
                style: _buttonTextStyle.copyWith(
                  color: isSelected ? _textColorOnPrimary : _textColorOnWhite,
                ),
              ),
            ),
            if (isSelected)
              Icon(Icons.check_circle, color: _textColorOnPrimary, size: 24)
            else
              Icon(Icons.radio_button_unchecked, color: _lightGreenAccent, size: 24),
          ],
        ),
      ),
    );
  }
}