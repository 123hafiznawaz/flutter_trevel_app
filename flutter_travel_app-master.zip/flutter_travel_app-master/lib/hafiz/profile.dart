import 'package:flutter/material.dart';

// Consider renaming file to profile_screen.dart
class ProfileScreen extends StatefulWidget { // Renamed class for clarity
  const ProfileScreen({super.key});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // --- Theme Colors ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32);
  static const Color _kWhiteColor = Colors.white;
  static const Color _kDarkTextColor = Color(0xFF1C1B1F);
  static const Color _kLightTextColor = Color(0xFF757575);
  static const Color _kDividerColor = Color(0xFFE0E0E0);
  static const Color _kIconColor = Color(0xFF4CAF50); // For list item icons
  static const Color _kLogoutButtonColor = Color(0xFFD32F2F);

  // --- State Variables ---
  bool _receiveUpdates = true;
  bool _preferWindowSeat = false;
  bool _enableDarkMode = false;
  String _selectedLanguage = 'English';
  final List<String> _languages = ['English', 'Spanish', 'French', 'German'];
  int _bottomNavIndex = 2; // 0: Dashboard, 1: My Bookings, 2: Profile

  // --- Sample User Data ---
  // Updated user data
  final Map<String, String> _userData = {
    'name': 'Hafiz M Nawaz', // Updated name
    'email': 'nawazmani@gmail.com', // Updated email
    'avatarUrl': 'assets/images/profile.jpg', // Updated to local asset path
  };

  void _onBottomNavItemTapped(int index) {
    if (_bottomNavIndex == index) {
      if (index == 2) print("Profile tab re-selected");
      return;
    }

    // Always ensure the state is updated for the bottom nav bar itself
    // before any navigation occurs, especially for routes that might replace the current one.
    setState(() {
      _bottomNavIndex = index;
    });

    switch (index) {
      case 0: // Dashboard
      // If coming from another tab to dashboard, remove all routes until dashboard
        Navigator.pushNamedAndRemoveUntil(context, '/dashboard', (Route<dynamic> route) => false);
        break;
      case 1: // My Bookings
      // If already on a page that can be popped (e.g. from dashboard to bookings),
      // just push. If not, consider pushReplacementNamed or pushNamedAndRemoveUntil.
      // For simplicity with bottom nav, often a new instance is pushed or a specific stack is managed.
        Navigator.pushNamed(context, '/mybookings'); // This will add to stack
        // If you want to ensure only one instance of MyBookings and Dashboard on stack when switching:
        // Navigator.pushReplacementNamed(context, '/mybookings'); // (if that's the desired flow)
        break;
      case 2: // Profile (Current Screen)
      // Already handled by setState above, no navigation needed if it's the current screen.
      // If ProfileScreen could be pushed multiple times, you might want logic here too.
        break;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kWhiteColor,
        elevation: 1.0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.grey[600]),
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            } else {
              // Fallback to dashboard if cannot pop (e.g., this is the first screen)
              Navigator.pushNamedAndRemoveUntil(context, '/dashboard', (Route<dynamic> route) => false);
            }
          },
        ),
        title: const Text(
          'Profile',
          style: TextStyle(
            color: _kPrimaryGreen,
            fontWeight: FontWeight.bold,
            fontFamily: 'Inter',
            fontSize: 24,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined, color: _kPrimaryGreen),
            onPressed: () {
              print('Edit profile tapped');
              // Example: Navigator.pushNamed(context, '/edit_profile');
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Edit Profile Action Triggered (Implement Navigation)')),
              );
            },
            tooltip: 'Edit Profile',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _buildUserDetailsSection(),
            const SizedBox(height: 20),
            _buildSectionDivider(),
            _buildSectionTitle('Travel Preferences'),
            _buildToggleOption(
              icon: Icons.notifications_active_outlined,
              title: 'Receive Travel Updates',
              value: _receiveUpdates,
              onChanged: (bool value) {
                setState(() {
                  _receiveUpdates = value;
                });
              },
            ),
            _buildToggleOption(
              icon: Icons.airline_seat_recline_normal_outlined,
              title: 'Prefer Window Seat',
              value: _preferWindowSeat,
              onChanged: (bool value) {
                setState(() {
                  _preferWindowSeat = value;
                });
              },
            ),
            const SizedBox(height: 10),
            _buildSectionDivider(),
            _buildSectionTitle('Settings'),
            _buildToggleOption(
              icon: Icons.dark_mode_outlined,
              title: 'Enable Dark Mode',
              value: _enableDarkMode,
              onChanged: (bool value) {
                setState(() {
                  _enableDarkMode = value;
                });
                print('Dark Mode Toggled: $_enableDarkMode');
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Dark Mode toggled (Implement Theme Change)')),
                );
              },
            ),
            _buildLanguageOption(),
            const SizedBox(height: 20),
            _buildSectionDivider(),
            _buildLogoutButton(),
            const SizedBox(height: 20),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _bottomNavIndex,
        onTap: _onBottomNavItemTapped,
        backgroundColor: _kWhiteColor,
        selectedItemColor: _kPrimaryGreen,
        unselectedItemColor: _kLightTextColor,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_rounded),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.work_history_rounded),
            label: 'My Bookings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildUserDetailsSection() {
    String? avatarPath = _userData['avatarUrl']; // Now expecting an asset path or empty/null
    String name = _userData['name'] ?? 'User';
    String email = _userData['email'] ?? 'No email';
    String avatarLetter = name.isNotEmpty ? name.substring(0, 1).toUpperCase() : '?';

    // Improved initial generation for names like "Hafiz M Nawaz" -> "HN"
    if (name.contains(' ')) {
      final parts = name.trim().split(' ');
      if (parts.length > 1 && parts[0].isNotEmpty && parts.last.isNotEmpty) {
        avatarLetter = '${parts[0][0]}${parts.last[0]}'.toUpperCase();
      } else if (parts.isNotEmpty && parts[0].isNotEmpty) {
        avatarLetter = parts[0][0].toUpperCase();
      }
    }


    ImageProvider? backgroundImage;
    if (avatarPath != null && avatarPath.isNotEmpty) {
      if (avatarPath.startsWith('assets/')) { // Check if it's an asset path
        backgroundImage = AssetImage(avatarPath);
      } else if (avatarPath.startsWith('http')) { // Basic check for network URL
        backgroundImage = NetworkImage(avatarPath);
      }
      // Add more checks if you support other types of image sources (e.g., FileImage)
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        children: <Widget>[
          CircleAvatar(
            radius: 35,
            backgroundColor: _kPrimaryGreen.withOpacity(0.2),
            backgroundImage: backgroundImage, // Use the determined ImageProvider
            onBackgroundImageError: backgroundImage != null ? (dynamic exception, StackTrace? stackTrace) {
              print('Error loading avatar image: $exception');
              // Optionally, you could setState here to clear the backgroundImage or show initials
            } : null,
            child: (backgroundImage == null) // Show initials if no image or error
                ? Text(
              avatarLetter,
              style: const TextStyle(
                  fontSize: 24,
                  color: _kPrimaryGreen,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Inter'),
            )
                : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  name,
                  style: const TextStyle(
                    color: _kDarkTextColor,
                    fontFamily: 'Inter',
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  email,
                  style: const TextStyle(
                    color: _kLightTextColor,
                    fontFamily: 'Inter',
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      child: Text(
        title,
        style: const TextStyle(
          color: _kPrimaryGreen,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter',
        ),
      ),
    );
  }

  Widget _buildToggleOption({
    required IconData icon,
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
      leading: Icon(icon, color: _kIconColor),
      title: Text(
        title,
        style: const TextStyle(
            color: _kDarkTextColor, fontFamily: 'Inter', fontSize: 16),
      ),
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: _kPrimaryGreen,
        inactiveTrackColor: _kLightTextColor.withOpacity(0.3),
      ),
      onTap: () => onChanged(!value),
    );
  }

  Widget _buildLanguageOption() {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
      leading: const Icon(Icons.language_outlined, color: _kIconColor),
      title: const Text(
        'Language',
        style: TextStyle(
            color: _kDarkTextColor, fontFamily: 'Inter', fontSize: 16),
      ),
      trailing: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedLanguage,
          icon: const Icon(Icons.arrow_drop_down, color: _kLightTextColor),
          style: const TextStyle(
              color: _kDarkTextColor, fontFamily: 'Inter', fontSize: 16),
          dropdownColor: _kWhiteColor,
          items: _languages.map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          onChanged: (String? newValue) {
            if (newValue != null) {
              setState(() {
                _selectedLanguage = newValue;
              });
              print('Language changed to: $_selectedLanguage');
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Language changed to $_selectedLanguage (Implement Localization)')),
              );
            }
          },
        ),
      ),
      onTap: () {
        // This onTap on ListTile might not be needed if DropdownButton handles interaction.
      },
    );
  }

  Widget _buildSectionDivider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Divider(color: _kDividerColor.withOpacity(0.6), height: 1.0),
    );
  }

  Widget _buildLogoutButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          icon: const Icon(Icons.logout, color: _kWhiteColor),
          label: const Text(
            'Logout',
            style: TextStyle(
                color: _kWhiteColor,
                fontFamily: 'Inter',
                fontSize: 16,
                fontWeight: FontWeight.w600),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: _kLogoutButtonColor,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            elevation: 2,
          ),
          onPressed: () {
            print('Logout tapped');
            // Ensure you have a '/logout' route defined in your MaterialApp
            // and appropriate logic to handle logout (e.g., clear user session, navigate to login).
            Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false); // Example: navigate to login and remove all previous routes
          },
        ),
      ),
    );
  }
}