import 'package:flutter/material.dart';

class HotelResultsWidget extends StatefulWidget {
  @override
  _HotelResultsWidgetState createState() => _HotelResultsWidgetState();
}

class _HotelResultsWidgetState extends State<HotelResultsWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.black87),
          onPressed: () {
            // Handle back button press
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          'Hotel Listings',
          style: TextStyle(
            color: Colors.black87,
            fontFamily: 'Inter', // Assuming Inter is available or defaults
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.filter_list, color: Colors.black87),
            onPressed: () {
              // Handle filter button press
              print('Filter button pressed');
            },
          ),
          SizedBox(width: 8), // Padding on the right
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(40.0),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // --- CORRECTED LINE FOR TIME DISPLAY ---
                Text(
                  _formatTime(DateTime.now()), // Call helper function for time formatting
                  style: TextStyle(
                    color: Colors.black54,
                    fontFamily: 'Roboto',
                    fontSize: 13,
                  ),
                ),
                Row(
                  children: <Widget>[
                    Icon(Icons.wifi, size: 18, color: Colors.black54),
                    SizedBox(width: 4),
                    Icon(Icons.signal_cellular_alt, size: 18, color: Colors.black54),
                    SizedBox(width: 4),
                    Icon(Icons.battery_full, size: 18, color: Colors.black54),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: <Widget>[
                HotelCard(
                  hotelName: 'Grand Hotel',
                  stars: 4,
                  imageAsset: 'assets/images/hotel_grand.jpg', // Placeholder, ensure you have these assets
                  price: '\$150/night',
                  location: 'Downtown',
                ),
                HotelCard(
                  hotelName: 'Beach Resort',
                  stars: 5,
                  imageAsset: 'assets/images/hotel_beach.jpg',
                  price: '\$280/night',
                  location: 'Coastal Area',
                ),
                HotelCard(
                  hotelName: 'City Inn',
                  stars: 3,
                  imageAsset: 'assets/images/hotel_cityinn.jpg',
                  price: '\$90/night',
                  location: 'City Center',
                ),
                HotelCard(
                  hotelName: 'Luxury Suites',
                  stars: 5,
                  imageAsset: 'assets/images/hotel_luxury.jpg',
                  price: '\$350/night',
                  location: 'Uptown',
                ),
                SizedBox(height: 20), // Spacing before the home indicator
              ],
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Container(
                width: 108,
                height: 4,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: Colors.black87,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Helper function to format time in 12-hour format with AM/PM
  String _formatTime(DateTime dateTime) {
    int hour = dateTime.hour;
    String ampm = 'AM';

    if (hour >= 12) {
      ampm = 'PM';
      if (hour > 12) {
        hour -= 12;
      }
    } else if (hour == 0) {
      hour = 12; // Midnight is 12 AM
    }

    String minute = dateTime.minute.toString().padLeft(2, '0');
    return '$hour:$minute $ampm';
  }
}

/// A reusable widget for displaying a single hotel card.
class HotelCard extends StatelessWidget {
  final String hotelName;
  final int stars;
  final String imageAsset;
  final String price;
  final String location;

  const HotelCard({
    Key? key,
    required this.hotelName,
    required this.stars,
    required this.imageAsset,
    required this.price,
    required this.location,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: 100,
                  height: 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: DecorationImage(
                      image: AssetImage(imageAsset), // Use AssetImage
                      fit: BoxFit.cover,
                    ),
                  ),
                  // Placeholder if image fails or not provided
                  child: Image.asset(
                    imageAsset,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Center(
                      child: Icon(Icons.hotel, size: 40, color: Colors.black26),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        hotelName,
                        style: TextStyle(
                          color: Colors.black87,
                          fontFamily: 'Inter',
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Row(
                        children: List.generate(5, (index) {
                          return Icon(
                            index < stars ? Icons.star : Icons.star_border,
                            color: Colors.amber, // Gold for stars
                            size: 18,
                          );
                        }),
                      ),
                      SizedBox(height: 4),
                      Text(
                        location,
                        style: TextStyle(
                          color: Colors.black54,
                          fontFamily: 'Inter',
                          fontSize: 14,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        price,
                        style: TextStyle(
                          color: Color(0xFF4CAF50), // A nice green
                          fontFamily: 'Inter',
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Expanded(
                  child: _ActionButton(
                    text: 'View Details',
                    backgroundColor: Color(0xFF4CAF50), // Green for primary action
                    textColor: Colors.white,
                    onPressed: () {
                      print('View Details for $hotelName pressed');
                    },
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: _ActionButton(
                    text: 'Book Now',
                    backgroundColor: Color(0xFFE8F5E9), // Lighter green for secondary action
                    textColor: Color(0xFF4CAF50), // Green text
                    onPressed: () {
                      print('Book Now for $hotelName pressed');
                      Navigator.pushNamed(context, '/bookingsummary');
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// A private helper widget for creating action buttons.
class _ActionButton extends StatelessWidget {
  final String text;
  final Color backgroundColor;
  final Color textColor;
  final VoidCallback onPressed;

  const _ActionButton({
    Key? key,
    required this.text,
    required this.backgroundColor,
    required this.textColor,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: backgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        elevation: 0,
        minimumSize: Size(double.infinity, 40), // Ensure buttons expand
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: textColor,
          fontFamily: 'Inter',
          fontSize: 15,
          fontWeight: FontWeight.w600, // Slightly bolder for professionalism
        ),
      ),
    );
  }
}