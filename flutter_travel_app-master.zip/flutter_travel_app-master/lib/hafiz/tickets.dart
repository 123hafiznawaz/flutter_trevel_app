import 'package:flutter/material.dart';

class TicketWidget extends StatelessWidget {
  const TicketWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          'Booking Confirmed',
          style: TextStyle(
            fontSize: 24, // Responsive font size
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: false, // Align title to left as seen in previous screens
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.05,
          vertical: screenHeight * 0.02,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: screenHeight * 0.02),
            Center(
              child: Container(
                width: screenWidth * 0.25, // Responsive size for the circle
                height: screenWidth * 0.25,
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1), // Light green background for the icon
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.green,
                    width: 2.0,
                  ),
                ),
                child: Icon(
                  Icons.check_circle_outline, // Checkmark icon
                  color: Colors.green,
                  size: screenWidth * 0.15, // Responsive icon size
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.03),
            Center(
              child: Text(
                'Your booking has been confirmed!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: screenWidth * 0.045, // Responsive font size
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.02),
            Center(
              child: Text(
                'Booking ID: #123456',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: screenWidth * 0.055, // Responsive font size
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.01),
            Center(
              child: Text(
                'Date: September 25, 2023',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: screenWidth * 0.04, // Responsive font size
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.04),
            // Placeholder for the ticket details section
            Container(
              width: double.infinity,
              height: screenHeight * 0.25, // Responsive height
              decoration: BoxDecoration(
                color: Colors.grey[100], // Light grey background
                borderRadius: BorderRadius.circular(15.0),
              ),
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Ticket Details will go here',
                    style: TextStyle(
                      fontSize: screenWidth * 0.04,
                      color: Colors.grey[700],
                    ),
                  ),
                  SizedBox(height: screenHeight * 0.01),
                  Text(
                    '(e.g., QR Code, Seat Number, Gate Info)',
                    style: TextStyle(
                      fontSize: screenWidth * 0.035,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: screenHeight * 0.04),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // Handle Download
                      print('Download button pressed');
                    },
                    icon: const Icon(Icons.download), // Icon for download
                    label: const Text('Download'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green, // Green button
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: screenHeight * 0.018),
                      textStyle: TextStyle(
                        fontSize: screenWidth * 0.04,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: screenWidth * 0.04),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // Handle Share
                      print('Share button pressed');
                    },
                    icon: const Icon(Icons.share), // Icon for share
                    label: const Text('Share'),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.green, width: 2), // Green border
                      foregroundColor: Colors.green, // Green text/icon
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: screenHeight * 0.018),
                      textStyle: TextStyle(
                        fontSize: screenWidth * 0.04,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: screenHeight * 0.04), // Spacing before the new button
            SizedBox(
              width: double.infinity, // Make button full width
              height: screenHeight * 0.07, // Responsive button height
              child: ElevatedButton(
                onPressed: () {
                  // Navigate to the dashboard
                  Navigator.pushNamed(context, '/dashboard');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade800, // Darker green for a primary action
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: TextStyle(
                    fontSize: screenWidth * 0.05, // Responsive font size
                    fontWeight: FontWeight.bold,
                  ),
                ),
                child: const Text('Go to Dashboard'),
              ),
            ),
            SizedBox(height: screenHeight * 0.02), // Add some bottom padding
          ],
        ),
      ),
      // bottomNavigationBar is removed here
    );
  }
}