import 'package:flutter/material.dart';

// It's good practice to name your widget files with snake_case: flight_details_widget.dart
// And your classes with UpperCamelCase: FlightDetailsWidget
// I'll keep your provided names for now.

class Flight_detailsWidget extends StatefulWidget {
  const Flight_detailsWidget({super.key}); // Added super.key

  @override
  _Flight_detailsWidgetState createState() => _Flight_detailsWidgetState();
}

class _Flight_detailsWidgetState extends State<Flight_detailsWidget> {
  // --- Theme Colors ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32); // A deep green
  static const Color _kWhiteColor = Colors.white;
  static const Color _kDarkTextColor = Color(0xFF1C1B1F); // Main text color
  static const Color _kLightTextColor = Color(0xFF757575); // Secondary text or icons
  static const Color _kBackgroundColor = Color(0xFFF0F0F0); // Light gray for background elements

  @override
  Widget build(BuildContext context) {
    // Using Scaffold for a standard app structure
    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        // backgroundColor: _kPrimaryGreen, // Making AppBar white for a cleaner look, title green
        backgroundColor: _kWhiteColor,
        elevation: 1.0, // Subtle shadow
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _kPrimaryGreen),
          onPressed: () {
            // Add navigation logic if needed, e.g., Navigator.pop(context);
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
          tooltip: 'Back',
        ),
        title: const Text(
          'Flight Details',
          style: TextStyle(
            color: _kPrimaryGreen, // Green title
            fontWeight: FontWeight.bold,
            fontFamily: 'Inter',
            fontSize: 22,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: _kPrimaryGreen),
            onPressed: () {
              // Add share functionality
            },
            tooltip: 'Share',
          ),
          IconButton(
            icon: const Icon(Icons.favorite_border, color: _kPrimaryGreen),
            // Use Icons.favorite for a filled heart if it's favorited
            onPressed: () {
              // Add favorite functionality
            },
            tooltip: 'Favorite',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // --- Airline Information Section ---
              _buildAirlineInfoCard(
                airlineName: 'American Airlines',
                flightType: 'Non-stop', // Or '1 Stop', etc.
                imageUrl: 'https://logo.clearbit.com/aa.com', // Example, replace with actual or placeholder
                // You can use a local asset: 'assets/images/american_airlines_logo.png'
              ),
              const SizedBox(height: 24),

              // --- Layover Information Section ---
              _buildSectionTitle('Layover Information'),
              _buildInfoRow(
                  icon: Icons.timelapse,
                  text: 'Layover in Dallas: 1 hour',
                  iconColor: _kPrimaryGreen),
              const SizedBox(height: 24),

              // --- Fare Conditions Section ---
              _buildSectionTitle('Fare Conditions'),
              _buildInfoRow(
                  icon: Icons.info_outline,
                  text: 'Non-refundable, changes allowed with fee',
                  iconColor: _kPrimaryGreen),
              // You can add more conditions here
              // _buildInfoRow(icon: Icons.luggage, text: '1 carry-on, 1 checked bag included'),

              const SizedBox(height: 32), // Spacer before the button
            ],
          ),
        ),
      ),
      // --- Bottom Navigation Bar for Booking Button ---
      bottomNavigationBar: _buildBookingButton(context), // Pass context here
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Text(
        title,
        style: const TextStyle(
          color: _kDarkTextColor,
          fontSize: 20,
          fontWeight: FontWeight.w600, // Bolder for section titles
          fontFamily: 'Inter',
        ),
      ),
    );
  }

  Widget _buildAirlineInfoCard({
    required String airlineName,
    required String flightType,
    String? imageUrl, // Optional image URL
    IconData? placeholderIcon, // Optional placeholder icon if no image
  }) {
    return Card(
      elevation: 2.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: <Widget>[
            Container(
              width: 70, // Increased size
              height: 70,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
                color: _kBackgroundColor, // Light gray background for the image/icon
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: imageUrl != null && imageUrl.isNotEmpty
                    ? Image.network(
                  imageUrl,
                  fit: BoxFit.contain, // Use contain to see the whole logo
                  errorBuilder: (context, error, stackTrace) {
                    return Icon(placeholderIcon ?? Icons.flight_takeoff, size: 35, color: _kPrimaryGreen);
                  },
                )
                    : Icon(placeholderIcon ?? Icons.flight_takeoff, size: 35, color: _kPrimaryGreen),
              ),
            ),
            const SizedBox(width: 16),
            Expanded( // Use Expanded to prevent overflow if text is long
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    airlineName,
                    style: const TextStyle(
                      color: _kDarkTextColor,
                      fontFamily: 'Inter',
                      fontSize: 18, // Slightly larger
                      fontWeight: FontWeight.w500, // Medium weight
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    flightType,
                    style: const TextStyle(
                      color: _kLightTextColor,
                      fontFamily: 'Inter',
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow({required IconData icon, required String text, Color? iconColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: <Widget>[
          Icon(icon, color: iconColor ?? _kPrimaryGreen, size: 24),
          const SizedBox(width: 12),
          Expanded( // Use Expanded for long text
            child: Text(
              text,
              style: const TextStyle(
                color: _kDarkTextColor,
                fontFamily: 'Inter',
                fontSize: 16,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBookingButton(BuildContext context) { // Accept context as a parameter
    return Container(
      padding: const EdgeInsets.all(16.0), // Padding around the button
      decoration: BoxDecoration(
        color: _kWhiteColor, // Background for the bottom bar
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 0,
            blurRadius: 5,
            offset: const Offset(0, -2), // Shadow on top
          ),
        ],
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: _kPrimaryGreen,
          padding: const EdgeInsets.symmetric(vertical: 16), // Taller button
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          minimumSize: const Size(double.infinity, 50), // Full width
        ),
        onPressed: () {
          // Navigate to the '/bookingsummary' route
          Navigator.pushNamed(context, '/bookingsummary');
        },
        child: const Text(
          'Continue to Book',
          style: TextStyle(
            color: _kWhiteColor,
            fontFamily: 'Inter',
            fontSize: 18, // Larger text
            fontWeight: FontWeight.w600, // Bolder
          ),
        ),
      ),
    );
  }
}