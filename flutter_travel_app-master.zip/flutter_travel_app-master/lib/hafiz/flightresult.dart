import 'package:flutter/material.dart';

class FlightResultsWidget extends StatefulWidget {
  @override
  _FlightResultsWidgetState createState() => _FlightResultsWidgetState();
}

class _FlightResultsWidgetState extends State<FlightResultsWidget> {
  @override
  Widget build(BuildContext context) {
    // Using MediaQuery for responsiveness
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white, // Overall background for the screen
      appBar: AppBar(
        backgroundColor: Colors.white, // AppBar background
        elevation: 0, // No shadow for a cleaner look
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.green.shade800), // Back button
          onPressed: () {
            // Handle back button press
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            // Using standard Flutter Icons for connectivity
            Icon(Icons.wifi, color: Colors.green.shade800, size: 20),
            SizedBox(width: 8),
            Icon(Icons.signal_cellular_alt, color: Colors.green.shade800, size: 20),
            SizedBox(width: 8),
            Icon(Icons.battery_full, color: Colors.green.shade800, size: 20),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: screenHeight * 0.02), // Responsive spacing
              Text(
                'Available Flights',
                style: TextStyle(
                  color: Colors.green.shade900,
                  fontFamily: 'Inter',
                  fontSize: screenWidth * 0.08, // Responsive font size
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: screenHeight * 0.02),
              Text(
                'Filters',
                style: TextStyle(
                  color: Colors.green.shade800,
                  fontFamily: 'Inter',
                  fontSize: screenWidth * 0.05,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: screenHeight * 0.01),
              // Filter Chips
              Row(
                children: <Widget>[
                  _buildFilterChip('Stops', isSelected: true),
                  SizedBox(width: 8),
                  _buildFilterChip('Time'),
                  SizedBox(width: 8),
                  _buildFilterChip('Price'),
                  // Add more filter chips as needed
                ],
              ),
              SizedBox(height: screenHeight * 0.03),

              // Flight Results List
              _buildFlightCard(
                airline: 'American Airlines',
                price: '\$250',
                logoColor: Colors.green.shade100, // Light green for logo background
                screenWidth: screenWidth,
                context: context, // Pass context to the helper method
              ),
              SizedBox(height: screenHeight * 0.02),
              _buildFlightCard(
                airline: 'Delta Airlines',
                price: '\$300',
                logoColor: Colors.green.shade100,
                screenWidth: screenWidth,
                context: context,
              ),
              SizedBox(height: screenHeight * 0.02),
              _buildFlightCard(
                airline: 'United Airlines',
                price: '\$280',
                logoColor: Colors.green.shade100,
                screenWidth: screenWidth,
                context: context,
              ),
              SizedBox(height: screenHeight * 0.02),
              _buildFlightCard(
                airline: 'Southwest Airlines',
                price: '\$275',
                logoColor: Colors.green.shade100,
                screenWidth: screenWidth,
                context: context,
              ),
              SizedBox(height: screenHeight * 0.02),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container( // Keep the container for the home indicator
        color: Colors.white,
        padding: EdgeInsets.symmetric(
            horizontal: 16, vertical: screenHeight * 0.02),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Removed the "Book Now" button
            SizedBox(height: screenHeight * 0.01), // Adjust spacing if needed
            Container(
              width: screenWidth * 0.3, // Responsive width for the home indicator
              height: 4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: Colors.green.shade900, // Darker green for indicator
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Helper method to build filter chips
  Widget _buildFilterChip(String label, {bool isSelected = false}) {
    return Chip(
      label: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.green.shade800,
          fontFamily: 'Inter',
          fontSize: 16,
        ),
      ),
      backgroundColor: isSelected ? Colors.green.shade800 : Colors.green.shade100,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isSelected ? Colors.transparent : Colors.green.shade300,
          width: 1,
        ),
      ),
    );
  }

  /// Helper method to build a flight card
  Widget _buildFlightCard({
    required String airline,
    required String price,
    required Color logoColor,
    required double screenWidth,
    required BuildContext context, // Added context to navigate
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: Offset(0, 3), // changes position of shadow
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: <Widget>[
          Container(
            width: screenWidth * 0.2, // Responsive width for logo container
            height: screenWidth * 0.2, // Keep it square
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: logoColor,
            ),
            child: Icon(
              Icons.flight, // Placeholder icon for airline logo
              color: Colors.green.shade700,
              size: screenWidth * 0.1,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  airline,
                  style: TextStyle(
                    color: Colors.green.shade900,
                    fontFamily: 'Inter',
                    fontSize: screenWidth * 0.045,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  price,
                  style: TextStyle(
                    color: Colors.green.shade600,
                    fontFamily: 'Inter',
                    fontSize: screenWidth * 0.04,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/flightdetail'); // Navigate to flightdetail
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green.shade800,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
            child: Text(
              'Book',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Inter',
                fontSize: screenWidth * 0.04,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}