import 'package:flutter/material.dart';

class Aisuggestions extends StatefulWidget {
  @override
  _AisuggestionsState createState() =>
      _AisuggestionsState();
}

class _AisuggestionsState
    extends State<Aisuggestions> {
  @override
  Widget build(BuildContext context) {
    // Get screen dimensions for responsiveness
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white, // White background
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0, // No shadow for a cleaner look
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Color.fromRGBO(28, 27, 31, 1)), // Back icon
          onPressed: () {
            Navigator.pop(context); // Example back navigation
          },
        ),
        title: Text(
          'AI Travel Suggestions', // Clear title for the page
          style: TextStyle(
            color: Color.fromRGBO(28, 27, 31, 1),
            fontFamily: 'Inter',
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true, // Center the title
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const SizedBox(height: 20),
              Text(
                'Personalized Travel Ideas',
                style: TextStyle(
                  color: Color.fromRGBO(28, 27, 31, 1),
                  fontFamily: 'Inter',
                  fontSize: 24, // Slightly larger for main heading
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 30),

              // Trending Destinations Section
              Text(
                'Trending Destinations',
                style: TextStyle(
                  color: Color.fromRGBO(28, 27, 31, 1),
                  fontFamily: 'Inter',
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 250, // Fixed height for horizontal list of cards
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 3, // Example count for trending destinations
                  itemBuilder: (context, index) {
                    final destinations = [
                      {'name': 'Paris', 'description': 'Eiffel Tower', 'image': 'https://picsum.photos/seed/paris/200/300'},
                      {'name': 'Tokyo', 'description': 'Shibuya Crossing', 'image': 'https://picsum.photos/seed/tokyo/200/300'},
                      {'name': 'London', 'description': 'Big Ben', 'image': 'https://picsum.photos/seed/london/200/300'},
                    ];
                    return _buildDestinationCard(
                      destinations[index]['name']!,
                      destinations[index]['description']!,
                      destinations[index]['image']!,
                      screenWidth * 0.65, // Responsive width for cards
                    );
                  },
                ),
              ),
              const SizedBox(height: 30),

              // Deals Based on Your History Section
              Text(
                'Deals Based on Your History',
                style: TextStyle(
                  color: Color.fromRGBO(28, 27, 31, 1),
                  fontFamily: 'Inter',
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 250, // Fixed height for horizontal list of cards
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 3, // Example count for deals
                  itemBuilder: (context, index) {
                    final deals = [
                      {'name': 'Bali', 'description': '50% Off', 'image': 'https://picsum.photos/seed/bali/200/300'},
                      {'name': 'New York', 'description': '30% Off', 'image': 'https://picsum.photos/seed/newyork/200/300'},
                      {'name': 'Miami', 'description': 'Special Package', 'image': 'https://picsum.photos/seed/miami/200/300'},
                    ];
                    return _buildDestinationCard(
                      deals[index]['name']!,
                      deals[index]['description']!,
                      deals[index]['image']!,
                      screenWidth * 0.65, // Responsive width for cards
                    );
                  },
                ),
              ),
              const SizedBox(height: 30),

              // Weekend Getaway Picks Section
              Text(
                'Weekend Getaway Picks',
                style: TextStyle(
                  color: Color.fromRGBO(28, 27, 31, 1),
                  fontFamily: 'Inter',
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 250, // Fixed height for horizontal list of cards
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 3, // Example count for weekend getaways
                  itemBuilder: (context, index) {
                    final getaways = [
                      {'name': 'Miami', 'description': 'Beaches', 'image': 'https://picsum.photos/seed/miami2/200/300'},
                      {'name': 'Chicago', 'description': 'City Vibes', 'image': 'https://picsum.photos/seed/chicago/200/300'},
                      {'name': 'San Diego', 'description': 'Coastal Bliss', 'image': 'https://picsum.photos/seed/sandiego/200/300'},
                    ];
                    return _buildDestinationCard(
                      getaways[index]['name']!,
                      getaways[index]['description']!,
                      getaways[index]['image']!,
                      screenWidth * 0.65, // Responsive width for cards
                    );
                  },
                ),
              ),
              const SizedBox(height: 40), // Padding at the bottom
            ],
          ),
        ),
      ),
    );
  }

  // Helper method for building destination cards
  Widget _buildDestinationCard(
      String title, String subtitle, String imageUrl, double cardWidth) {
    return Container(
      width: cardWidth, // Responsive width
      margin: const EdgeInsets.only(right: 16), // Space between cards
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Color.fromRGBO(239, 241, 245, 1), // Light grey card background
        boxShadow: [ // Subtle shadow for a professional look
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3), // changes position of shadow
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ClipRRect(
            borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            child: Image.network(
              imageUrl,
              height: 140, // Fixed height for image
              width: double.infinity,
              fit: BoxFit.cover,
              // Add a simple error builder for network images
              errorBuilder: (context, error, stackTrace) => Container(
                height: 140,
                color: Colors.grey[300],
                child: Center(
                  child: Icon(Icons.broken_image, color: Colors.grey),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color.fromRGBO(28, 27, 31, 1),
                    fontFamily: 'Inter',
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Color.fromRGBO(160, 156, 171, 1),
                    fontFamily: 'Inter',
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}