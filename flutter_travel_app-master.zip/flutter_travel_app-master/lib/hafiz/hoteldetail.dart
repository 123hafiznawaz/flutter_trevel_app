import 'package:flutter/material.dart';

// Consider renaming file to hotel_details_widget.dart for consistency
// And class to HotelDetailsWidget (UpperCamelCase)

class Hotel_detailsWidget extends StatefulWidget {
  const Hotel_detailsWidget({super.key}); // Added super.key

  @override
  _Hotel_detailsWidgetState createState() => _Hotel_detailsWidgetState();
}

class _Hotel_detailsWidgetState extends State<Hotel_detailsWidget> {
  // --- Theme Colors ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32);
  static const Color _kWhiteColor = Colors.white;
  static const Color _kDarkTextColor = Color(0xFF1C1B1F);
  static const Color _kLightTextColor = Color(0xFF757575);
  static const Color _kBackgroundColor = Color(0xFFF0F0F0); // Light gray for image/card backgrounds
  static const Color _kStarColor = Colors.amber;

  // --- Sample Data (Replace with actual data source) ---
  final List<String> _sampleImageUrls = [
    'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8aG90ZWx8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGhvdGVsfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fGhvdGVsfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fGhvdGVsfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60',
  ];

  final List<Map<String, dynamic>> _amenities = [
    {'name': 'Free Wi-Fi', 'icon': Icons.wifi},
    {'name': '24/7 Room Service', 'icon': Icons.room_service},
    {'name': 'Spa & Wellness', 'icon': Icons.spa},
    {'name': 'Gym', 'icon': Icons.fitness_center},
    {'name': 'Swimming Pool', 'icon': Icons.pool},
    {'name': 'Restaurant', 'icon': Icons.restaurant},
    {'name': 'Parking', 'icon': Icons.local_parking},
  ];

  final List<Map<String, String>> _reviews = [
    {
      'name': 'John Doe',
      'review': 'An amazing experience! The staff was lovely and the amenities were first class.',
      'avatar': 'JD' // Could be an image URL too
    },
    {
      'name': 'Jane Smith',
      'review': 'Truly a luxury experience, highly recommend to anyone visiting!',
      'avatar': 'JS'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kWhiteColor,
        elevation: 1.0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _kPrimaryGreen),
          onPressed: () {
            if (Navigator.canPop(context)) Navigator.pop(context);
          },
          tooltip: 'Back',
        ),
        title: const Text(
          'Luxury Suites', // Example Hotel Name
          style: TextStyle(
            color: _kPrimaryGreen,
            fontWeight: FontWeight.bold,
            fontFamily: 'Inter',
            fontSize: 22,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: _kPrimaryGreen),
            onPressed: () { /* Share functionality */ },
            tooltip: 'Share',
          ),
          IconButton(
            icon: const Icon(Icons.favorite_border, color: _kPrimaryGreen),
            onPressed: () { /* Favorite functionality */ },
            tooltip: 'Favorite',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // --- Image Gallery ---
            _buildImageGallery(),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // --- Hotel Name & Rating ---
                  _buildHotelHeader(
                    hotelName: 'The Grand Palace Hotel', // Example
                    location: '123 Luxury Ave, Dream City', // Example
                    rating: 4.8, // Example rating
                    reviewCount: 350, // Example review count
                  ),
                  const SizedBox(height: 20),

                  // --- Description Section ---
                  _buildSectionTitle('Description'),
                  const Text(
                    'Enjoy your stay in our luxury suites, equipped with top-notch amenities and breathtaking views. Experience unparalleled comfort and service in the heart of the city.',
                    style: TextStyle(
                      color: _kDarkTextColor,
                      fontFamily: 'Inter',
                      fontSize: 16,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // --- Amenities Section ---
                  _buildSectionTitle('Amenities'),
                  _buildAmenitiesGrid(),
                  const SizedBox(height: 24),

                  // --- Guest Reviews Section ---
                  _buildSectionTitle('Guest Reviews'),
                  ..._reviews.map((review) => _buildReviewCard(
                    name: review['name']!,
                    reviewText: review['review']!,
                    avatarText: review['avatar'],
                  )).toList(),
                  const SizedBox(height: 20), // Space before bottom bar
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBookingButton(),
    );
  }

  Widget _buildImageGallery() {
    return SizedBox(
      height: 250, // Adjust height as needed
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _sampleImageUrls.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: EdgeInsets.only(
              left: index == 0 ? 16.0 : 8.0,
              right: index == _sampleImageUrls.length - 1 ? 16.0 : 0.0,
              top: 16.0,
              bottom: 16.0,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12.0),
              child: Image.network(
                _sampleImageUrls[index],
                width: MediaQuery.of(context).size.width * 0.8, // Adjust width
                height: 220,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    height: 220,
                    color: _kBackgroundColor,
                    child: const Icon(Icons.broken_image, size: 50, color: _kLightTextColor),
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHotelHeader({
    required String hotelName,
    required String location,
    required double rating,
    required int reviewCount,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          hotelName,
          style: const TextStyle(
            color: _kDarkTextColor,
            fontFamily: 'Inter',
            fontSize: 26, // Larger for hotel name
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            const Icon(Icons.location_on, color: _kPrimaryGreen, size: 18),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                location,
                style: const TextStyle(
                  color: _kLightTextColor,
                  fontFamily: 'Inter',
                  fontSize: 14,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            const Icon(Icons.star, color: _kStarColor, size: 22),
            const SizedBox(width: 4),
            Text(
              '$rating',
              style: const TextStyle(
                color: _kDarkTextColor,
                fontFamily: 'Inter',
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              '($reviewCount reviews)',
              style: const TextStyle(
                color: _kLightTextColor,
                fontFamily: 'Inter',
                fontSize: 14,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0, top: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          color: _kDarkTextColor,
          fontSize: 20,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter',
        ),
      ),
    );
  }

  Widget _buildAmenitiesGrid() {
    return Wrap(
      spacing: 10.0, // Horizontal spacing between chips
      runSpacing: 10.0, // Vertical spacing between lines of chips
      children: _amenities.map((amenity) {
        return Chip(
          avatar: Icon(amenity['icon'] as IconData, color: _kPrimaryGreen, size: 18),
          label: Text(
            amenity['name'] as String,
            style: const TextStyle(fontFamily: 'Inter', color: _kDarkTextColor),
          ),
          backgroundColor: _kPrimaryGreen.withOpacity(0.1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
            side: BorderSide(color: _kPrimaryGreen.withOpacity(0.3)),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
        );
      }).toList(),
    );
  }

  Widget _buildReviewCard({required String name, required String reviewText, String? avatarText, String? avatarImageUrl}) {
    return Card(
      elevation: 1.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: _kPrimaryGreen,
                  foregroundColor: _kWhiteColor,
                  radius: 20,
                  child: avatarImageUrl != null
                      ? ClipOval(child: Image.network(avatarImageUrl, fit: BoxFit.cover, width: 40, height: 40))
                      : Text(avatarText ?? '?', style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Inter')),
                ),
                const SizedBox(width: 10),
                Text(
                  name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Inter',
                    fontSize: 16,
                    color: _kDarkTextColor,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              reviewText,
              style: const TextStyle(
                fontFamily: 'Inter',
                fontSize: 15,
                color: _kLightTextColor,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBookingButton() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: _kWhiteColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 0,
            blurRadius: 5,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: _kPrimaryGreen,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          minimumSize: const Size(double.infinity, 50),
        ),
        onPressed: () {
          print('Book Room tapped');
          // Example: Navigator.push(context, MaterialPageRoute(builder: (context) => BookingScreen()));
        },
        child: const Text(
          'Book Room',
          style: TextStyle(
            color: _kWhiteColor,
            fontFamily: 'Inter',
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}