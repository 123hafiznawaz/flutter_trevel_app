import 'dart:async';
import 'package:flutter/material.dart';
// If you are using a custom font like 'Inter', ensure it's in pubspec.yaml
// and the font files are in your assets.

class SplashWidget extends StatefulWidget {
  const SplashWidget({super.key}); // Added super.key

  @override
  _SplashWidgetState createState() => _SplashWidgetState();
}

class _SplashWidgetState extends State<SplashWidget> {
  // --- Theme Colors ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32); // A nice shade of green
  static const Color _kWhiteColor = Colors.white;
  static const Color _kDarkTextColor = Color(0xFF1C1B1F); // Dark text for contrast
  static const Color _kLightTextColor = Color(0xFF4A4A4A); // Lighter text for taglines

  @override
  void initState() {
    super.initState();
    _navigateToNextScreen();
  }

  void _navigateToNextScreen() {
    Timer(const Duration(seconds: 5), () {
      if (mounted) { // Check if the widget is still in the tree
        // Replace '/home' with your actual target route (e.g., '/login', '/dashboard')
        Navigator.of(context).pushReplacementNamed('/getstarted');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions for responsive sizing if needed, though for splash it's often centered.
    // final screenHeight = MediaQuery.of(context).size.height;
    // final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: _kWhiteColor, // White background
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              // App Logo - Replace with your actual logo
              // You can use Image.asset('assets/images/your_logo.png')
              // For now, using a placeholder icon
              Icon(
                Icons.travel_explore, // Placeholder icon, e.g., for a travel app
                size: 120,
                color: _kPrimaryGreen,
              ),
              const SizedBox(height: 24),

              // App Name
              Text(
                'TravelApp', // Your App Name
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _kDarkTextColor,
                  fontFamily: 'Inter', // Ensure this font is available or remove
                  fontSize: 32, // Larger size for app name
                  fontWeight: FontWeight.bold, // Bold for prominence
                ),
              ),
              const SizedBox(height: 12),

              // Tagline
              Text(
                'Book Hotels, Flights, and Taxis Effortlessly',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _kLightTextColor,
                  fontFamily: 'Inter', // Ensure this font is available or remove
                  fontSize: 16,
                  fontWeight: FontWeight.normal,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 40),

              // Loading Indicator
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(_kPrimaryGreen),
                strokeWidth: 3,
              ),
              const SizedBox(height: 16),
              Text(
                'Loading...',
                style: TextStyle(
                  color: _kPrimaryGreen.withOpacity(0.8),
                  fontSize: 14,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}