import 'package:flutter/material.dart';

// Define your theme colors here for easy management
class AppColors {
  static const Color primaryGreen = Color(0xFF4CAF50); // A standard green
  static const Color lightGreenBackground = Color(0xFFE8F5E9); // A very light green
  static const Color white = Colors.white;
  static const Color darkText = Color(0xFF1C1B1F); // Dark grey for text
  static const Color lightText = Color(0xFFA09CAB); // Lighter grey for hints/subtitles
  static const Color textFieldBackground = Color(0xFFEFF1F5); // Light grey for text field background
  static const Color cardBackground = Color(0xFFF5F5F5); // Light grey for cards
}

class TransportBookingScreen extends StatefulWidget {
  const TransportBookingScreen({super.key});

  @override
  _TransportBookingScreenState createState() => _TransportBookingScreenState();
}

class _TransportBookingScreenState extends State<TransportBookingScreen> {
  final TextEditingController _pickupController = TextEditingController();
  final TextEditingController _dropoffController = TextEditingController();

  @override
  void dispose() {
    _pickupController.dispose();
    _dropoffController.dispose();
    super.dispose();
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Text(
        title,
        style: TextStyle(
          color: AppColors.darkText,
          fontFamily: 'Inter', // Make sure you have this font in pubspec.yaml
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildTextField(String hintText, TextEditingController controller) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.textFieldBackground,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: const TextStyle(
            color: AppColors.lightText,
            fontFamily: 'Inter',
            fontSize: 16,
          ),
          border: InputBorder.none,
          contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        style: const TextStyle(
          color: AppColors.darkText,
          fontFamily: 'Inter',
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildDateTimeSelection() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Start',
                  style: TextStyle(
                    color: AppColors.lightText,
                    fontFamily: 'Inter',
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Tue, Oct 24', // This would typically be dynamic
                  style: TextStyle(
                    color: AppColors.darkText,
                    fontFamily: 'Inter',
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'End',
                  style: TextStyle(
                    color: AppColors.lightText,
                    fontFamily: 'Inter',
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Wed, Oct 25', // This would typically be dynamic
                  style: TextStyle(
                    color: AppColors.darkText,
                    fontFamily: 'Inter',
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVehicleTile({
    required IconData icon,
    required String type,
    required String price,
    bool isSelected = false, // Example for selection state
  }) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: isSelected ? 4.0 : 1.0,
      color: isSelected ? AppColors.lightGreenBackground : AppColors.cardBackground,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: isSelected
            ? const BorderSide(color: AppColors.primaryGreen, width: 1.5)
            : BorderSide.none,
      ),
      child: InkWell( // To make it tappable
        onTap: () {
          // Handle vehicle selection
          print('$type selected');
          // You'd typically update state here
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: <Widget>[
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.primaryGreen.withOpacity(0.1) : AppColors.textFieldBackground, // Slight variant from main card bg
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, size: 32, color: isSelected ? AppColors.primaryGreen : AppColors.darkText.withOpacity(0.7)),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      type,
                      style: TextStyle(
                        color: AppColors.darkText,
                        fontFamily: 'Inter',
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      price,
                      style: const TextStyle(
                        color: AppColors.lightText,
                        fontFamily: 'Inter',
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              if (isSelected)
                const Icon(Icons.check_circle, color: AppColors.primaryGreen)
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: AppColors.white, // For back arrow and title color
        elevation: 2.0, // Subtle shadow
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            // Handle back navigation
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
        ),
        title: const Text(
          'Transport Booking',
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 20, // AppBar title size
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea( // Ensures content is not obscured by notches, status bars etc.
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Pickup Location Section
                _buildSectionTitle('Pickup Location'),
                _buildTextField('Enter pickup location', _pickupController),
                const SizedBox(height: 16),

                // Drop-off Location Section
                _buildSectionTitle('Drop-off Location'),
                _buildTextField('Enter drop-off location', _dropoffController),
                const SizedBox(height: 16),

                // Date & Time Section
                _buildSectionTitle('Date & Time'),
                _buildDateTimeSelection(),
                const SizedBox(height: 24),

                // Available Vehicles Section
                _buildSectionTitle('Available Vehicles'),
                _buildVehicleTile(
                  icon: Icons.directions_car_outlined,
                  type: 'Sedan',
                  price: '\$25',
                  isSelected: false, // Example
                ),
                _buildVehicleTile(
                  icon: Icons.airport_shuttle_outlined, // More distinct icon for Van/SUV
                  type: 'SUV',
                  price: '\$40',
                  isSelected: true, // Example of a selected item
                ),
                _buildVehicleTile(
                  icon: Icons.rv_hookup_outlined, // Another option
                  type: 'Van',
                  price: '\$50',
                ),
                const SizedBox(height: 24),

                // Example of a confirmation button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryGreen,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      textStyle: const TextStyle(
                        fontSize: 18,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.bold,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: () {
                      // --- NAVIGATE TO BOOKING SUMMARY ---
                      print('Confirm Booking button pressed!');
                      print('Pickup: ${_pickupController.text}');
                      print('Dropoff: ${_dropoffController.text}');
                      Navigator.pushNamed(context, '/bookingsummary');
                      // Add logic for date/time and selected vehicle
                    },
                    child: const Text(
                      'Confirm Booking',
                      style: TextStyle(color: AppColors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}