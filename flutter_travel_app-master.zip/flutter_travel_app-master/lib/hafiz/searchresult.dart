// search_results_screen.dart
import 'package:flutter/material.dart';
import 'dart:math'; // For random data generation

// --- Theme Colors (consistent with SearchFilterWidget) ---
const Color _kPrimaryGreen = Color(0xFF2E7D32);
const Color _kWhiteColor = Colors.white;
const Color _kDarkTextColor = Color(0xFF1C1B1F);
const Color _kLightTextColor = Color(0xFF757575);
const Color _kCardBackgroundColor = Color(0xFFF5F5F5); // Slightly off-white for cards
const Color _kAccentColor = Color(0xFFFFC107); // An accent like amber for ratings etc.

// --- Data Models (Simplified) ---
class FlightData {
  final String airline;
  final String from;
  final String to;
  final String departureTime;
  final String arrivalTime;
  final String duration;
  final int stops;
  final double price;
  final IconData airlineIcon;

  FlightData({
    required this.airline,
    required this.from,
    required this.to,
    required this.departureTime,
    required this.arrivalTime,
    required this.duration,
    required this.stops,
    required this.price,
    required this.airlineIcon,
  });
}

class HotelData {
  final String name;
  final String location;
  final double rating;
  final int stars;
  final double pricePerNight;
  final String imageUrl; // Placeholder, you'd use Image.network
  final List<String> amenities;
  final IconData hotelIcon;

  HotelData({
    required this.name,
    required this.location,
    required this.rating,
    required this.stars,
    required this.pricePerNight,
    required this.imageUrl,
    required this.amenities,
    this.hotelIcon = Icons.hotel_rounded,
  });
}

class TransportData {
  final String type; // e.g., "Sedan", "SUV", "Bus"
  final String provider;
  final int capacity;
  final double price;
  final String availableFrom;
  final IconData transportIcon;

  TransportData({
    required this.type,
    required this.provider,
    required this.capacity,
    required this.price,
    required this.availableFrom,
    required this.transportIcon,
  });
}

class SearchResultsScreen extends StatefulWidget {
  final Map<String, dynamic> filters;

  const SearchResultsScreen({super.key, required this.filters});

  @override
  _SearchResultsScreenState createState() => _SearchResultsScreenState();
}

class _SearchResultsScreenState extends State<SearchResultsScreen> {
  late String _currentFilterType;
  List<dynamic> _results = [];
  bool _isLoading = true;

  // --- Mock Data Generation ---
  final Random _random = Random();

  List<FlightData> _generateMockFlights(Map<String, dynamic> filters) {
    int numberOfResults = _random.nextInt(5) + 3; // 3 to 7 results
    List<FlightData> flights = [];
    List<String> airlines = ["SkyLink", "AirJet", "TravelWings", "GlobalFly"];
    List<IconData> airlineIcons = [Icons.flight_class_rounded, Icons.airplanemode_active, Icons.connecting_airports, Icons.public];

    for (int i = 0; i < numberOfResults; i++) {
      int stopsFilter = -1; // -1 means any stops
      if(filters['stops'] != null) {
        if (filters['stops']['nonStop'] == true) stopsFilter = 0;
        else if (filters['stops']['oneStop'] == true) stopsFilter = 1;
        else if (filters['stops']['twoPlusStops'] == true) stopsFilter = 2;
      }

      int currentStops = stopsFilter != -1 ? stopsFilter : _random.nextInt(3);
      if (stopsFilter == 2 && currentStops < 2) currentStops = 2; // ensure 2+ if selected

      flights.add(FlightData(
        airline: airlines[_random.nextInt(airlines.length)],
        airlineIcon: airlineIcons[_random.nextInt(airlineIcons.length)],
        from: "City A",
        to: "City B",
        departureTime: "${_random.nextInt(12) + 8}:00 AM",
        arrivalTime: "${_random.nextInt(12) + 1}:00 PM",
        duration: "${_random.nextInt(10) + 2}h ${_random.nextInt(60)}m",
        stops: currentStops,
        price: (filters['priceRange']?['start'] ?? 100.0) + _random.nextDouble() * ((filters['priceRange']?['end'] ?? 1000.0) - (filters['priceRange']?['start'] ?? 100.0)),
      ));
    }
    // Simple price sort if 'Price' is selected
    if (filters['sortBy'] == 'Price') {
      flights.sort((a, b) => a.price.compareTo(b.price));
    } else if (filters['sortBy'] == 'Duration') {
      // Basic duration sort (needs more robust parsing for real app)
      flights.sort((a,b) => a.duration.length.compareTo(b.duration.length));
    }
    return flights;
  }

  List<HotelData> _generateMockHotels(Map<String, dynamic> filters) {
    int numberOfResults = _random.nextInt(4) + 2; // 2 to 5 results
    List<HotelData> hotels = [];
    List<String> hotelNames = ["Grand Plaza", "Cozy Inn", "Lakeside Resort", "Downtown Suites"];
    List<String> amenitiesSample = ["Free Wi-Fi", "Pool", "Gym", "Parking", "Breakfast"];

    Map<int, bool> starFilters = filters['starRatings'] is Map ? Map<int, bool>.from(filters['starRatings'].map((k,v) => MapEntry(int.tryParse(k.toString()) ?? 0, v as bool))) : {};
    bool anyStarSelected = starFilters.values.any((isSelected) => isSelected);

    for (int i = 0; i < numberOfResults; i++) {
      int currentStars = _random.nextInt(5) + 1;
      if (anyStarSelected && ! (starFilters[currentStars] ?? false) ) {
        // If star filter is active and this hotel doesn't match, try to find one that does or skip
        int? matchingStar = starFilters.entries.firstWhere((e) => e.value, orElse: () => const MapEntry(-1, false)).key;
        if(matchingStar != -1) currentStars = matchingStar;
        else continue; // skip if no matching star preference
      }

      hotels.add(HotelData(
        name: hotelNames[_random.nextInt(hotelNames.length)],
        location: "Some Address, City",
        rating: (_random.nextDouble() * 2.0 + 3.0).clamp(3.0, 5.0), // 3.0 to 5.0
        stars: currentStars,
        pricePerNight: (filters['priceRange']?['start'] ?? 50.0) + _random.nextDouble() * ((filters['priceRange']?['end'] ?? 500.0) - (filters['priceRange']?['start'] ?? 50.0)),
        imageUrl: "https://via.placeholder.com/300x200.png?text=Hotel+Image", // Placeholder
        amenities: List.generate(_random.nextInt(3)+2, (_) => amenitiesSample[_random.nextInt(amenitiesSample.length)]).toSet().toList(),
      ));
    }
    if (filters['sortBy'] == 'Price') {
      hotels.sort((a, b) => a.pricePerNight.compareTo(b.pricePerNight));
    }
    // No duration sort for hotels in this example
    return hotels;
  }

  List<TransportData> _generateMockTransport(Map<String, dynamic> filters) {
    int numberOfResults = _random.nextInt(3) + 2; // 2 to 4 results
    List<TransportData> transports = [];
    List<String> transportTypes = ["Sedan", "SUV", "Minivan", "Luxury Car"];
    List<String> providers = ["CityCab", "RideEasy", "GoDrive", "QuickWheels"];
    List<IconData> transportIcons = [Icons.directions_car_filled_rounded, Icons.airport_shuttle_rounded, Icons.local_taxi_rounded, Icons.emoji_transportation_rounded];


    for (int i = 0; i < numberOfResults; i++) {
      transports.add(TransportData(
        type: transportTypes[_random.nextInt(transportTypes.length)],
        provider: providers[_random.nextInt(providers.length)],
        capacity: _random.nextInt(4) + 2, // 2 to 5 passengers
        price: (filters['priceRange']?['start'] ?? 20.0) + _random.nextDouble() * ((filters['priceRange']?['end'] ?? 200.0) - (filters['priceRange']?['start'] ?? 20.0)),
        availableFrom: "Available Now",
        transportIcon: transportIcons[_random.nextInt(transportIcons.length)],
      ));
    }
    if (filters['sortBy'] == 'Price') {
      transports.sort((a, b) => a.price.compareTo(b.price));
    }
    // No duration sort for transport in this example, but you could add one
    return transports;
  }

  void _fetchResults() {
    setState(() {
      _isLoading = true;
    });
    // Simulate network delay
    Future.delayed(const Duration(milliseconds: 800), () {
      _currentFilterType = widget.filters['filterType'] ?? 'Flight';
      if (_currentFilterType == 'Flight') {
        _results = _generateMockFlights(widget.filters);
      } else if (_currentFilterType == 'Hotel') {
        _results = _generateMockHotels(widget.filters);
      } else if (_currentFilterType == 'Transport') {
        _results = _generateMockTransport(widget.filters);
      } else {
        _results = [];
      }
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _fetchResults();
  }

  // This is how the screen would "refresh" if new filters are passed.
  // For this to work, the SearchResultsScreen instance itself must be replaced
  // (e.g., by navigating to a new one with updated filters).
  @override
  void didUpdateWidget(covariant SearchResultsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.filters != oldWidget.filters) {
      _fetchResults();
    }
  }

  @override
  Widget build(BuildContext context) {
    String title = "Search Results";
    if (_results.isNotEmpty) {
      title = "${_currentFilterType}s Found (${_results.length})";
    } else if (!_isLoading) {
      title = "No ${_currentFilterType}s Found";
    }

    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kPrimaryGreen,
        iconTheme: const IconThemeData(color: _kWhiteColor),
        title: Text(
          title,
          style: const TextStyle(
            color: _kWhiteColor,
            fontWeight: FontWeight.bold,
            fontFamily: 'Inter',
          ),
        ),
        elevation: 2,
        // Potentially add a refresh button or filter edit button here
        // actions: [
        //   IconButton(
        //     icon: Icon(Icons.filter_list_rounded, color: _kWhiteColor),
        //     onPressed: () {
        //       // Logic to go back to filter screen, perhaps pass current filters
        //       Navigator.pop(context); // Simple pop for now
        //     },
        //     tooltip: 'Edit Filters',
        //   )
        // ],
      ),
      body: _isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(_kPrimaryGreen),
        ),
      )
          : _results.isEmpty
          ? _buildEmptyState()
          : ListView.separated(
        padding: const EdgeInsets.all(16.0),
        itemCount: _results.length,
        itemBuilder: (context, index) {
          if (_currentFilterType == 'Flight') {
            return _FlightResultCard(flight: _results[index] as FlightData);
          } else if (_currentFilterType == 'Hotel') {
            return _HotelResultCard(hotel: _results[index] as HotelData);
          } else if (_currentFilterType == 'Transport') {
            return _TransportResultCard(transport: _results[index] as TransportData);
          }
          return const SizedBox.shrink(); // Should not happen
        },
        separatorBuilder: (context, index) => const SizedBox(height: 12),
      ),
    );
  }

  Widget _buildEmptyState() {
    IconData iconData;
    String message;

    switch (_currentFilterType) {
      case 'Flight':
        iconData = Icons.flight_takeoff_rounded;
        message = "No flights match your criteria. Try adjusting the filters.";
        break;
      case 'Hotel':
        iconData = Icons.hotel_rounded;
        message = "No hotels available for your selection. Please refine your search.";
        break;
      case 'Transport':
        iconData = Icons.directions_car_rounded;
        message = "No transport options found. Consider changing your search parameters.";
        break;
      default:
        iconData = Icons.search_off_rounded;
        message = "No results found. Please check your filters.";
    }

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(iconData, size: 80, color: _kLightTextColor),
            const SizedBox(height: 20),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 18,
                color: _kDarkTextColor,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.filter_list_alt, color: _kWhiteColor),
              label: const Text('Adjust Filters', style: TextStyle(color: _kWhiteColor, fontFamily: 'Inter')),
              style: ElevatedButton.styleFrom(
                backgroundColor: _kPrimaryGreen,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                textStyle: const TextStyle(fontSize: 16, fontFamily: 'Inter', fontWeight: FontWeight.w500),
              ),
              onPressed: () {
                // Navigate back to the filter screen
                if (Navigator.canPop(context)) {
                  Navigator.pop(context);
                }
              },
            )
          ],
        ),
      ),
    );
  }
}

// --- Result Card Widgets ---

class _FlightResultCard extends StatelessWidget {
  final FlightData flight;

  const _FlightResultCard({required this.flight});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.zero, // ListView.separated handles spacing
      color: _kCardBackgroundColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(flight.airlineIcon, color: _kPrimaryGreen, size: 28),
                const SizedBox(width: 10),
                Text(
                  flight.airline,
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _kDarkTextColor,
                      fontFamily: 'Inter'),
                ),
                const Spacer(),
                Text(
                  "\$${flight.price.toStringAsFixed(2)}",
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: _kPrimaryGreen,
                      fontFamily: 'Inter'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildFlightTimePoint(flight.from, flight.departureTime, Icons.flight_takeoff_rounded),
                Flexible(
                  child: Column(
                    children: [
                      Text(flight.duration, style: const TextStyle(color: _kDarkTextColor, fontFamily: 'Inter', fontWeight: FontWeight.w500)),
                      const SizedBox(height: 2),
                      SizedBox(
                        width: 80, // Adjust width as needed
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Divider(color: _kLightTextColor.withOpacity(0.5), thickness: 1.5),
                            if(flight.stops > 0)
                              Container(
                                padding: const EdgeInsets.all(2),
                                decoration: BoxDecoration(color: _kCardBackgroundColor, shape: BoxShape.circle),
                                child: Icon(Icons.circle, size: 8, color: _kPrimaryGreen),
                              )
                          ],
                        ),
                      ),
                      Text(
                        flight.stops == 0 ? "Non-stop" : "${flight.stops} Stop${flight.stops > 1 ? 's' : ''}",
                        style: const TextStyle(fontSize: 12, color: _kLightTextColor, fontFamily: 'Inter'),
                      ),
                    ],
                  ),
                ),
                _buildFlightTimePoint(flight.to, flight.arrivalTime, Icons.flight_land_rounded, isArrival: true),
              ],
            ),
            const SizedBox(height: 10),
            Center(
              child: ElevatedButton(
                onPressed: () { /* TODO: Implement booking or details */ },
                style: ElevatedButton.styleFrom(
                    backgroundColor: _kPrimaryGreen,
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                    textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w500)
                ),
                child: const Text("View Deal", style: TextStyle(color: _kWhiteColor)),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildFlightTimePoint(String city, String time, IconData icon, {bool isArrival = false}) {
    return Column(
      crossAxisAlignment: isArrival ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          city,
          style: const TextStyle(fontSize: 16, color: _kDarkTextColor, fontWeight: FontWeight.w600, fontFamily: 'Inter'),
        ),
        const SizedBox(height: 4),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!isArrival) Icon(icon, size: 18, color: _kPrimaryGreen),
            if (!isArrival) const SizedBox(width: 4),
            Text(time, style: const TextStyle(color: _kLightTextColor, fontFamily: 'Inter')),
            if (isArrival) const SizedBox(width: 4),
            if (isArrival) Icon(icon, size: 18, color: _kPrimaryGreen),
          ],
        )
      ],
    );
  }
}

class _HotelResultCard extends StatelessWidget {
  final HotelData hotel;

  const _HotelResultCard({required this.hotel});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      color: _kCardBackgroundColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Image.network( // In a real app, use a CachedNetworkImage or similar
              hotel.imageUrl,
              height: 150,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                height: 150,
                color: _kLightTextColor.withOpacity(0.1),
                child: const Center(child: Icon(Icons.broken_image_rounded, size: 40, color: _kLightTextColor)),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hotel.name,
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _kDarkTextColor,
                      fontFamily: 'Inter'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.location_on_rounded, size: 16, color: _kLightTextColor),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        hotel.location,
                        style: const TextStyle(fontSize: 13, color: _kLightTextColor, fontFamily: 'Inter'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    ...List.generate(5, (index) => Icon(
                      index < hotel.stars ? Icons.star_rounded : Icons.star_border_rounded,
                      color: _kAccentColor,
                      size: 20,
                    )),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: _kPrimaryGreen,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        hotel.rating.toStringAsFixed(1),
                        style: const TextStyle(color: _kWhiteColor, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Inter'),
                      ),
                    ),
                  ],
                ),
                if(hotel.amenities.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6.0,
                    runSpacing: 4.0,
                    children: hotel.amenities.take(3).map((amenity) => Chip( // Show max 3 amenities for brevity
                      label: Text(amenity, style: const TextStyle(fontSize: 10, fontFamily: 'Inter')),
                      backgroundColor: _kPrimaryGreen.withOpacity(0.1),
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 0),
                      labelStyle: const TextStyle(color: _kPrimaryGreen, fontFamily: 'Inter'),
                      visualDensity: VisualDensity.compact,
                    )).toList(),
                  ),
                ],

                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "\$${hotel.pricePerNight.toStringAsFixed(2)}",
                          style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: _kPrimaryGreen,
                              fontFamily: 'Inter'),
                        ),
                        const Text(
                          "/ night",
                          style: TextStyle(fontSize: 12, color: _kLightTextColor, fontFamily: 'Inter'),
                        ),
                      ],
                    ),
                    ElevatedButton(
                      onPressed: () { /* TODO: Implement booking or details */ },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: _kPrimaryGreen,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                          textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w500)
                      ),
                      child: const Text("View Details", style: TextStyle(color: _kWhiteColor)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TransportResultCard extends StatelessWidget {
  final TransportData transport;

  const _TransportResultCard({required this.transport});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      color: _kCardBackgroundColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(transport.transportIcon, color: _kPrimaryGreen, size: 30),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    transport.type,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: _kDarkTextColor,
                        fontFamily: 'Inter'),
                  ),
                ),
                Text(
                  "\$${transport.price.toStringAsFixed(2)}",
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: _kPrimaryGreen,
                      fontFamily: 'Inter'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              "Provider: ${transport.provider}",
              style: const TextStyle(fontSize: 14, color: _kLightTextColor, fontFamily: 'Inter'),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.person_outline_rounded, size: 16, color: _kLightTextColor),
                const SizedBox(width: 4),
                Text(
                  "Capacity: ${transport.capacity} passengers",
                  style: const TextStyle(fontSize: 14, color: _kLightTextColor, fontFamily: 'Inter'),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              transport.availableFrom,
              style: const TextStyle(fontSize: 14, color: _kPrimaryGreen, fontWeight: FontWeight.w500, fontFamily: 'Inter'),
            ),
            const SizedBox(height: 12),
            Center(
              child: ElevatedButton(
                onPressed: () { /* TODO: Implement booking or details */ },
                style: ElevatedButton.styleFrom(
                    backgroundColor: _kPrimaryGreen,
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                    textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w500)
                ),
                child: const Text("Book Now", style: TextStyle(color: _kWhiteColor)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}