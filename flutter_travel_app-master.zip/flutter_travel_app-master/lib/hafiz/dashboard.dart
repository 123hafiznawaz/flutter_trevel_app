import 'package:flutter/material.dart';

// Enum to manage the content type displayed
enum ContentType { personalized, flights, hotels, transport }

class HomeWidget extends StatefulWidget {
  const HomeWidget({super.key});

  @override
  _HomeWidgetState createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> {
  // --- Theme Colors ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32);
  static const Color _kWhiteColor = Colors.white;
  static const Color _kLightGrayColor = Color(0xFFF0F0F0);
  static const Color _kDarkTextColor = Color(0xFF1C1B1F);
  static const Color _kLightTextColor = Color(0xFF757575);

  int _currentIndex = 0; // For BottomNavigationBar
  ContentType _selectedContentType = ContentType.personalized; // To manage displayed content

  // --- Sample Data ---
  final List<Map<String, dynamic>> _flightRecommendations = [
    {
      'title': 'Paris Direct',
      'subtitle': 'Lowest fare this month!',
      'imagePath': 'assets/images/paris.jpg', // Added imagePath
      'price': '\$250',
      // 'icon': Icons.flight_takeoff, // Icon can be kept for other purposes or removed
    },
    {
      'title': 'Tokyo Express',
      'subtitle': 'Includes extra baggage',
      'imagePath': 'assets/images/tokyo.jpg', // Added imagePath
      'price': '\$720',
      // 'icon': Icons.flight,
    },
    {
      'title': 'Rome Getaway',
      'subtitle': 'Weekend special',
      'imagePath': 'assets/images/rome.jpg', // Added imagePath
      'price': '\$310',
      // 'icon': Icons.airplanemode_active,
    },
    {
      'title': 'London Weekender',
      'subtitle': 'Quick trip deal',
      'imagePath': 'assets/images/london.jpg', // Added imagePath
      'price': '\$180',
      // 'icon': Icons.flight_land,
    },
    {
      'title': 'NYC Business Class',
      'subtitle': 'Fly in comfort',
      'imagePath': 'assets/images/nyc.jpg', // Added imagePath
      'price': '\$950',
      // 'icon': Icons.flight,
    },
  ];

  final List<Map<String, dynamic>> _hotelRecommendations = [
    {
      'title': 'The Grand Alpine',
      'subtitle': 'Mountain views, 5-star',
      'imagePath': 'assets/images/alpine.jpg', // Added imagePath
      'rating': '4.8',
      // 'icon': Icons.hotel,
    },
    {
      'title': 'Beachside Bungalow',
      'subtitle': 'Steps from the ocean',
      'imagePath': 'assets/images/beachside.jpg', // Added imagePath
      'rating': '4.5',
      // 'icon': Icons.beach_access,
    },
    {
      'title': 'City Center Loft',
      'subtitle': 'Modern & convenient',
      'imagePath': 'assets/images/cityloft.jpg', // Added imagePath
      'rating': '4.7',
      // 'icon': Icons.location_city,
    },
    {
      'title': 'Desert Oasis Resort',
      'subtitle': 'Luxury spa included',
      'imagePath': 'assets/images/desert.jpg', // Added imagePath
      'rating': '4.9',
      // 'icon': Icons.spa,
    },
    {
      'title': 'Urban Boutique Hotel',
      'subtitle': 'Chic and central',
      'imagePath': 'assets/images/urban.jpg', // Added imagePath
      'rating': '4.6',
      // 'icon': Icons.business,
    },
  ];

  final List<Map<String, dynamic>> _transportRecommendations = [
    {
      'title': 'City Limo Service',
      'subtitle': 'Arrive in style',
      'imagePath': 'assets/images/citylimo.jpg', // Added imagePath
      'price': 'From \$50',
      // 'icon': Icons.local_taxi,
    },
    {
      'title': 'Airport Shuttle',
      'subtitle': 'Reliable & Affordable',
      'imagePath': 'assets/images/shuttle.jpg', // Added imagePath
      'price': '\$25 per person',
      // 'icon': Icons.airport_shuttle,
    },
    {
      'title': 'Rent-A-Car Deals',
      'subtitle': 'Explore freely',
      'imagePath': 'assets/images/rentcar.jpg', // Added imagePath
      'price': 'Starting \$30/day',
      // 'icon': Icons.directions_car_filled,
    },
  ];


  void _onTabTapped(int index) {
    if (_currentIndex == index && index == 0) {
      setState(() {
        _selectedContentType = ContentType.personalized;
      });
      return;
    }

    setState(() {
      _currentIndex = index;
      if (index == 0) {
        _selectedContentType = ContentType.personalized;
      }
    });

    switch (index) {
      case 0:
        break;
      case 1:
        Navigator.pushNamed(context, '/mybookings');
        break;
      case 2:
        Navigator.pushNamed(context, '/profile');
        break;
    }
  }

  void _onQuickActionTapped(ContentType type) {
    setState(() {
      _selectedContentType = type;
    });
  }

  Widget _buildContentBody(double screenWidth) {
    if (_selectedContentType == ContentType.flights) {
      return Column(
        children: [
          _buildRecommendationSection(
            title: 'Flight Deals You Might Like',
            recommendations: _flightRecommendations,
            itemBuilder: (context, item) =>
                _buildFlightRecommendationCard(item, screenWidth),
          ),
          const SizedBox(height: 24),
        ],
      );
    } else if (_selectedContentType == ContentType.hotels) {
      return Column(
        children: [
          _buildRecommendationSection(
            title: 'Suggested Stays',
            recommendations: _hotelRecommendations,
            itemBuilder: (context, item) =>
                _buildHotelRecommendationCard(item, screenWidth),
          ),
          const SizedBox(height: 24),
        ],
      );
    } else if (_selectedContentType == ContentType.transport) {
      return Column(
        children: [
          _buildRecommendationSection(
            title: 'Transport Options',
            recommendations: _transportRecommendations,
            itemBuilder: (context, item) =>
                _buildTransportRecommendationCard(item, screenWidth),
          ),
          const SizedBox(height: 24),
        ],
      );
    }

    // Default: Personalized Content
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(
            'Personalized For You',
            style: TextStyle(
              color: _kDarkTextColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: 'Inter',
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(
            'Based on your travel history & preferences',
            style: TextStyle(
              color: _kLightTextColor,
              fontSize: 14,
              fontFamily: 'Inter',
            ),
          ),
        ),
        const SizedBox(height: 16),
        _buildRecommendationSection(
          title: 'Flight Deals You Might Like',
          recommendations: _flightRecommendations,
          itemBuilder: (context, item) =>
              _buildFlightRecommendationCard(item, screenWidth),
        ),
        const SizedBox(height: 24),
        _buildRecommendationSection(
          title: 'Suggested Stays',
          recommendations: _hotelRecommendations,
          itemBuilder: (context, item) =>
              _buildHotelRecommendationCard(item, screenWidth),
        ),
        const SizedBox(height: 24),
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kPrimaryGreen,
        elevation: 2,
        title: const Text(
          'Dashboard',
          style: TextStyle(
            color: _kWhiteColor,
            fontWeight: FontWeight.bold,
            fontFamily: 'Inter',
          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.search, color: _kWhiteColor, size: 28),
            tooltip: 'Search',
            onPressed: () {
              Navigator.pushNamed(context, '/search');
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const SizedBox(height: 16),
            _buildQuickActionCategories(),
            const SizedBox(height: 16),
            if (_selectedContentType != ContentType.personalized)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.arrow_back_ios_new, size: 16),
                  label: const Text('Back to All Suggestions'),
                  onPressed: () {
                    setState(() {
                      _selectedContentType = ContentType.personalized;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kLightGrayColor,
                    foregroundColor: _kDarkTextColor,
                    elevation: 1,
                  ),
                ),
              ),
            _buildContentBody(screenWidth),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
        backgroundColor: _kWhiteColor,
        selectedItemColor: _kPrimaryGreen,
        unselectedItemColor: _kLightTextColor,
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_rounded),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.work_history_rounded),
            label: 'My Bookings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionCategories() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          _buildCategoryIcon(Icons.flight_takeoff, 'Flights', () {
            _onQuickActionTapped(ContentType.flights);
          }),
          _buildCategoryIcon(Icons.hotel, 'Hotels', () {
            _onQuickActionTapped(ContentType.hotels);
          }),
          _buildCategoryIcon(Icons.directions_car, 'Transport', () {
            _onQuickActionTapped(ContentType.transport);
          }),
        ],
      ),
    );
  }

  Widget _buildCategoryIcon(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _kPrimaryGreen.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 28, color: _kPrimaryGreen),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(
                  color: _kDarkTextColor,
                  fontSize: 13,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecommendationSection({
    required String title,
    required List<Map<String, dynamic>> recommendations,
    required Widget Function(BuildContext, Map<String, dynamic>) itemBuilder,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: _kDarkTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/moresuggestions',
                      arguments: title);
                },
                child: const Text(
                  'View All',
                  style: TextStyle(
                      color: _kPrimaryGreen,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter'),
                ),
              )
            ],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          height: 240, // Adjust as needed, ensure it fits image + text
          child: recommendations.isEmpty
              ? Center(child: Text('No ${title.toLowerCase()} available right now.', style: TextStyle(color: _kLightTextColor)))
              : ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.only(left: 16, right: 6),
            itemCount: recommendations.length,
            itemBuilder: (context, index) {
              return itemBuilder(context, recommendations[index]);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildImageContainer(String? imagePath, {IconData? fallbackIcon}) {
    return Container(
      height: 130, // Fixed height for the image part of the card
      width: double.infinity,
      decoration: BoxDecoration(
        color: _kPrimaryGreen.withOpacity(0.1), // Fallback background
      ),
      child: imagePath != null
          ? Image.asset(
        imagePath,
        fit: BoxFit.cover, // Ensures the image covers the container
        errorBuilder: (context, error, stackTrace) {
          // Fallback to Icon if image fails to load
          print("Error loading image: $imagePath, $error");
          return Icon(fallbackIcon ?? Icons.broken_image, size: 50, color: _kPrimaryGreen);
        },
      )
          : Icon(fallbackIcon ?? Icons.image_not_supported, size: 50, color: _kPrimaryGreen), // Placeholder if no imagePath
    );
  }

  Widget _buildFlightRecommendationCard(
      Map<String, dynamic> flight, double screenWidth) {
    return Card(
      margin: const EdgeInsets.only(right: 10, bottom: 8),
      elevation: 2,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: SizedBox(
        width: screenWidth * 0.7,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _buildImageContainer(flight['imagePath'], fallbackIcon: flight['icon'] ?? Icons.flight_takeoff),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min, // Important for text wrapping
                children: <Widget>[
                  Text(
                    flight['title'],
                    style: const TextStyle(
                      color: _kDarkTextColor,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Inter',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    flight['subtitle'],
                    style: const TextStyle(
                      color: _kLightTextColor,
                      fontSize: 13,
                      fontFamily: 'Inter',
                    ),
                    maxLines: 1, // Keep subtitle concise
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    flight['price'],
                    style: const TextStyle(
                      color: _kPrimaryGreen,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHotelRecommendationCard(
      Map<String, dynamic> hotel, double screenWidth) {
    return Card(
      margin: const EdgeInsets.only(right: 10, bottom: 8),
      elevation: 2,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: SizedBox(
        width: screenWidth * 0.7,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _buildImageContainer(hotel['imagePath'], fallbackIcon: hotel['icon'] ?? Icons.hotel),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    hotel['title'],
                    style: const TextStyle(
                      color: _kDarkTextColor,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Inter',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    hotel['subtitle'],
                    style: const TextStyle(
                      color: _kLightTextColor,
                      fontSize: 13,
                      fontFamily: 'Inter',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 18),
                      const SizedBox(width: 4),
                      Text(
                        hotel['rating'],
                        style: const TextStyle(
                          color: _kDarkTextColor,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTransportRecommendationCard(
      Map<String, dynamic> transport, double screenWidth) {
    return Card(
      margin: const EdgeInsets.only(right: 10, bottom: 8),
      elevation: 2,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: SizedBox(
        width: screenWidth * 0.7,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _buildImageContainer(transport['imagePath'], fallbackIcon: transport['icon'] ?? Icons.directions_car),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    transport['title'],
                    style: const TextStyle(
                      color: _kDarkTextColor,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Inter',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    transport['subtitle'],
                    style: const TextStyle(
                      color: _kLightTextColor,
                      fontSize: 13,
                      fontFamily: 'Inter',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    transport['price'] ?? '',
                    style: const TextStyle(
                      color: _kPrimaryGreen,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}