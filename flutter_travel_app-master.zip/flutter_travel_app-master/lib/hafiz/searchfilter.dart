// searchfilter.dart
// Ensure this import path is correct for your project structure
// import 'package:YOUR_APP_NAME/search_results_screen.dart'; // <--- !!! IMPORTANT: REPLACE YOUR_APP_NAME !!!
import 'package:flutter/material.dart';
import 'dart:math'; // For min/max
import 'package:hafizmnawaz/hafiz/searchresult.dart';

class SearchFilterWidget extends StatefulWidget {
  const SearchFilterWidget({super.key});

  @override
  _SearchFilterWidgetState createState() => _SearchFilterWidgetState();
}

class _SearchFilterWidgetState extends State<SearchFilterWidget> {
  // --- Theme Colors ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32);
  static const Color _kWhiteColor = Colors.white;
  // static const Color _kLightGrayColor = Color(0xFFF0F0F0); // Not explicitly used, but good to have
  static const Color _kDarkTextColor = Color(0xFF1C1B1F);
  static const Color _kLightTextColor = Color(0xFF757575);
  static const Color _kSelectedColor = _kPrimaryGreen;
  static const Color _kUnselectedColor = Color(0xFFE0E0E0);

  // --- Filter State Variables ---
  String _selectedFilterType = 'Flight';
  String _sortBy = 'Price';

  bool _nonStop = false;
  bool _oneStop = false;
  bool _twoPlusStops = false;

  bool _freeWifi = false;
  bool _breakfastIncluded = false;
  bool _poolAccess = false;

  RangeValues _currentPriceRange = const RangeValues(100, 800);
  final double _minPrice = 0;
  final double _maxPrice = 1500;

  RangeValues _currentDurationRange = const RangeValues(2, 12);
  final double _minDuration = 1;
  final double _maxDuration = 24;

  final Map<int, bool> _starRatings = {
    5: false,
    4: false,
    3: false,
    2: false,
    1: false,
  };

  @override
  void initState() {
    super.initState();
    _currentPriceRange = RangeValues(
        _minPrice + (_maxPrice - _minPrice) * 0.1, _maxPrice * 0.7);
    _currentDurationRange = RangeValues(
        max(_minDuration, _minDuration + (_maxDuration - _minDuration) * 0.1),
        min(_maxDuration, _maxDuration * 0.75));
  }

  void _clearAllFilters() {
    setState(() {
      _selectedFilterType = 'Flight';
      _sortBy = 'Price';
      _nonStop = false;
      _oneStop = false;
      _twoPlusStops = false;
      _freeWifi = false;
      _breakfastIncluded = false;
      _poolAccess = false;
      _currentPriceRange = RangeValues(
          _minPrice + (_maxPrice - _minPrice) * 0.1, _maxPrice * 0.7);
      _currentDurationRange = RangeValues(
          max(_minDuration, _minDuration + (_maxDuration - _minDuration) * 0.1),
          min(_maxDuration, _maxDuration * 0.75));
      _starRatings.updateAll((key, value) => false);
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All filters cleared!', style: TextStyle(fontFamily: 'Inter')),
          backgroundColor: _kPrimaryGreen,
        ),
      );
    }
  }

  void _applyFilters() {
    Map<String, dynamic> appliedFilters = {
      'filterType': _selectedFilterType,
      'sortBy': _sortBy,
      'priceRange': {
        'start': _currentPriceRange.start,
        'end': _currentPriceRange.end,
      },
    };

    // Add durationRange only if applicable and not for Hotels
    if (_selectedFilterType == 'Flight' || _selectedFilterType == 'Transport') {
      appliedFilters['durationRange'] = {
        'start': _currentDurationRange.start,
        'end': _currentDurationRange.end,
      };
    }

    if (_selectedFilterType == 'Flight') {
      appliedFilters['stops'] = {
        'nonStop': _nonStop,
        'oneStop': _oneStop,
        'twoPlusStops': _twoPlusStops,
      };
    }

    if (_selectedFilterType == 'Hotel') {
      appliedFilters['amenities'] = {
        'freeWifi': _freeWifi,
        'breakfastIncluded': _breakfastIncluded,
        'poolAccess': _poolAccess,
      };
      // Convert int keys to String keys for starRatings,
      // as SearchResultsScreen mock data expects String keys.
      Map<String, bool> stringKeyedStarRatings = {};
      _starRatings.forEach((key, value) {
        if (value) { // Only include selected ratings
          stringKeyedStarRatings[key.toString()] = value;
        }
      });
      appliedFilters['starRatings'] = stringKeyedStarRatings;
    }

    // Navigate to the SearchResultsScreen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SearchResultsScreen(filters: appliedFilters),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    bool showDurationSortOption = _selectedFilterType == 'Flight' || _selectedFilterType == 'Transport';

    // If Duration sort is selected but the filter type changes to Hotel, reset sort to Price.
    // This is done here to ensure setState is not called during build if _buildSortByToggle tries to do it.
    if (_sortBy == 'Duration' && _selectedFilterType == 'Hotel') {
      _sortBy = 'Price'; // Update directly, will be reflected in next build
    }


    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kPrimaryGreen,
        leading: IconButton(
          icon: const Icon(Icons.close, color: _kWhiteColor),
          onPressed: () => Navigator.of(context).pop(),
          tooltip: 'Close Filters',
        ),
        title: const Text(
          'Filters',
          style: TextStyle(
              color: _kWhiteColor,
              fontWeight: FontWeight.bold,
              fontFamily: 'Inter'),
        ),
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _buildFilterTypeSelector(),
            const SizedBox(height: 24),

            _buildSectionTitle('Sort By'),
            _buildSortByToggle(showDurationSortOption), // Pass the flag
            const SizedBox(height: 24),

            if (_selectedFilterType == 'Flight') ...[
              _buildSectionTitle('Stops'),
              _buildCheckboxOption('Non-stop', _nonStop, (val) => setState(() => _nonStop = val!)),
              _buildCheckboxOption('1 Stop', _oneStop, (val) => setState(() => _oneStop = val!)),
              _buildCheckboxOption('2+ Stops', _twoPlusStops, (val) => setState(() => _twoPlusStops = val!)),
              const SizedBox(height: 24),
            ],

            if (_selectedFilterType == 'Hotel') ...[
              _buildSectionTitle('Amenities'),
              _buildCheckboxOption('Free Wi-Fi', _freeWifi, (val) => setState(() => _freeWifi = val!), leadingIcon: Icons.wifi),
              _buildCheckboxOption('Breakfast Included', _breakfastIncluded, (val) => setState(() => _breakfastIncluded = val!), leadingIcon: Icons.free_breakfast),
              _buildCheckboxOption('Pool Access', _poolAccess, (val) => setState(() => _poolAccess = val!), leadingIcon: Icons.pool),
              const SizedBox(height: 24),
              _buildSectionTitle('Star Rating'),
              ...(_starRatings.keys.toList()..sort((a, b) => b.compareTo(a))).map((stars) { // Sort descending
                return _buildCheckboxOption(
                  '$stars Star${stars > 1 ? "s" : ""}',
                  _starRatings[stars]!,
                      (val) => setState(() => _starRatings[stars] = val!),
                  leadingIcon: Icons.star,
                  iconColor: Colors.amber,
                );
              }).toList(),
              const SizedBox(height: 24),
            ],

            _buildSectionTitle('Price Range (\$${_currentPriceRange.start.round()} - \$${_currentPriceRange.end.round()})'),
            _buildPriceRangeSlider(),
            const SizedBox(height: 24),

            if (showDurationSortOption) ...[ // Use the same flag
              _buildSectionTitle('Duration (${_currentDurationRange.start.round()}h - ${_currentDurationRange.end.round()}h)'),
              _buildDurationRangeSlider(),
              const SizedBox(height: 24),
            ],

            const SizedBox(height: 6),
          ],
        ),
      ),
      bottomNavigationBar: _buildApplyClearButtons(),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0, top: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          color: _kDarkTextColor,
          fontSize: 20,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter',
        ),
      ),
    );
  }

  Widget _buildFilterTypeSelector() {
    final types = ['Flight', 'Hotel', 'Transport'];
    return Center(
      child: ToggleButtons(
        isSelected: types.map((type) => _selectedFilterType == type).toList(),
        onPressed: (index) {
          setState(() {
            _selectedFilterType = types[index];
            // If the new type is 'Hotel' and sort was by 'Duration', reset to 'Price'.
            // This logic is now primarily handled before build, but this acts as a direct update.
            if (_selectedFilterType == 'Hotel' && _sortBy == 'Duration') {
              _sortBy = 'Price';
            }
          });
        },
        borderRadius: BorderRadius.circular(8.0),
        selectedBorderColor: _kPrimaryGreen,
        selectedColor: _kWhiteColor,
        fillColor: _kPrimaryGreen,
        color: _kPrimaryGreen,
        splashColor: _kPrimaryGreen.withOpacity(0.12),
        constraints: BoxConstraints(
            minWidth: (MediaQuery.of(context).size.width - 48) / types.length,
            minHeight: 40.0),
        children: types.map((type) {
          IconData icon;
          switch (type) {
            case 'Flight': icon = Icons.flight_takeoff; break;
            case 'Hotel': icon = Icons.hotel; break;
            case 'Transport': icon = Icons.directions_car; break;
            default: icon = Icons.category;
          }
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 18),
                const SizedBox(width: 6),
                Text(type, style: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w500)),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildSortByToggle(bool showDurationOption) {
    List<Widget> buttons = [
      Expanded(
        child: _buildToggleButton('Price', _sortBy == 'Price', () {
          setState(() => _sortBy = 'Price');
        }),
      ),
    ];

    if (showDurationOption) {
      buttons.add(const SizedBox(width: 10)); // Add spacing
      buttons.add(Expanded(
        child: _buildToggleButton('Duration', _sortBy == 'Duration', () {
          setState(() => _sortBy = 'Duration');
        }),
      ));
    }
    // No need for Future.microtask here as the logic to reset _sortBy is handled
    // before the build method or directly in _buildFilterTypeSelector.

    return Row(children: buttons);
  }

  Widget _buildToggleButton(String text, bool isSelected, VoidCallback onPressed) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        backgroundColor: isSelected ? _kSelectedColor : _kWhiteColor,
        side: BorderSide(
            color: isSelected ? _kSelectedColor : _kUnselectedColor,
            width: 1.5),
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: isSelected ? _kWhiteColor : _kDarkTextColor,
          fontWeight: FontWeight.w500,
          fontFamily: 'Inter',
        ),
      ),
    );
  }

  Widget _buildCheckboxOption(String title, bool value, ValueChanged<bool?> onChanged, {IconData? leadingIcon, Color? iconColor}) {
    return InkWell(
      onTap: () => onChanged(!value),
      borderRadius: BorderRadius.circular(4.0),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6.0),
        child: Row(
          children: <Widget>[
            Checkbox(
              value: value,
              onChanged: onChanged,
              activeColor: _kPrimaryGreen,
              checkColor: _kWhiteColor,
              visualDensity: VisualDensity.compact,
              side: BorderSide(
                  color: value ? _kPrimaryGreen : _kLightTextColor.withOpacity(0.7), // Slightly softer border for unchecked
                  width: 1.5),
            ),
            if (leadingIcon != null) ...[
              Icon(leadingIcon, color: iconColor ?? _kPrimaryGreen, size: 20),
              const SizedBox(width: 8),
            ] else ...[
              const SizedBox(width: 4), // Less space if no icon before text
            ],
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: _kDarkTextColor,
                  fontSize: 16,
                  fontFamily: 'Inter',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPriceRangeSlider() {
    return RangeSlider(
      values: _currentPriceRange,
      min: _minPrice,
      max: _maxPrice,
      divisions: 50, // Increased divisions for finer control
      activeColor: _kPrimaryGreen,
      inactiveColor: _kPrimaryGreen.withOpacity(0.3),
      labels: RangeLabels(
        '\$${_currentPriceRange.start.round()}',
        '\$${_currentPriceRange.end.round()}',
      ),
      onChanged: (RangeValues values) {
        if (values.start <= values.end) {
          setState(() {
            _currentPriceRange = values;
          });
        }
      },
    );
  }

  Widget _buildDurationRangeSlider() {
    return RangeSlider(
      values: _currentDurationRange,
      min: _minDuration,
      max: _maxDuration,
      divisions: (_maxDuration - _minDuration).toInt(), // One division per hour
      activeColor: _kPrimaryGreen,
      inactiveColor: _kPrimaryGreen.withOpacity(0.3),
      labels: RangeLabels(
        '${_currentDurationRange.start.round()}h',
        '${_currentDurationRange.end.round()}h',
      ),
      onChanged: (RangeValues values) {
        if (values.start <= values.end) {
          setState(() {
            _currentDurationRange = values;
          });
        }
      },
    );
  }

  Widget _buildApplyClearButtons() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      decoration: BoxDecoration(
        color: _kWhiteColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 0,
            blurRadius: 5,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: OutlinedButton(
              onPressed: _clearAllFilters,
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                side: const BorderSide(color: _kPrimaryGreen, width: 1.5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
              ),
              child: const Text(
                'Clear All',
                style: TextStyle(
                  color: _kPrimaryGreen,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton(
              onPressed: _applyFilters,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kPrimaryGreen,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                elevation: 2,
              ),
              child: const Text(
                'Apply Filters',
                style: TextStyle(
                  color: _kWhiteColor,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}