import 'package:flutter/material.dart';
//intl.dart import was removed

// For a more professional look, let's define some theme constants
class AppColors {
  static const Color primaryGreen = Color(0xFF2E7D32); // Deep green
  static const Color lightGreen = Color(0xFFE8F5E9); // Light green for selection
  static const Color darkText = Color(0xFF1C1B1F);
  static const Color lightText = Color(0xFF757575);
  static const Color white = Colors.white;
  static const Color textFieldBackground = Color(0xFFF0F0F0);
  static const Color disabledColor = Color(0xFFBDBDBD);
}

enum TripType { oneWay, roundTrip, multiCity }

class FlightSearchWidget extends StatefulWidget {
  const FlightSearchWidget({super.key});

  @override
  _FlightSearchWidgetState createState() => _FlightSearchWidgetState();
}

class _FlightSearchWidgetState extends State<FlightSearchWidget> {
  TripType _selectedTripType = TripType.oneWay;

  final TextEditingController _fromController = TextEditingController();
  final TextEditingController _toController = TextEditingController();

  DateTime? _departureDate;
  DateTime? _returnDate;

  String? _selectedClass; // e.g., 'Economy', 'Business'
  int _passengerCount = 1;

  final List<String> _flightClasses = ['Economy', 'Premium Economy', 'Business', 'First'];
  final List<int> _passengerNumbers = List.generate(10, (index) => index + 1); // 1 to 10

  @override
  void dispose() {
    _fromController.dispose();
    _toController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context, bool isDepartureDate) async {
    final DateTime initialDate = (isDepartureDate
        ? _departureDate
        : _returnDate ?? _departureDate) ??
        DateTime.now();
    final DateTime firstDate = isDepartureDate
        ? DateTime.now()
        : _departureDate ?? DateTime.now();

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: firstDate,
      lastDate: DateTime(DateTime.now().year + 2),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryGreen,
              onPrimary: AppColors.white,
              surface: AppColors.white,
              onSurface: AppColors.darkText,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: AppColors.primaryGreen,
              ),
            ),
            dialogBackgroundColor: AppColors.white,
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isDepartureDate) {
          _departureDate = picked;
          if (_selectedTripType == TripType.roundTrip && _returnDate != null && _returnDate!.isBefore(_departureDate!)) {
            _returnDate = null;
          }
        } else {
          _returnDate = picked;
        }
      });
    }
  }

  void _handleSearch() {
    if (_fromController.text.isEmpty || _toController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter departure and destination.')),
      );
      return;
    }
    if (_departureDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a departure date.')),
      );
      return;
    }
    if (_selectedTripType == TripType.roundTrip && _returnDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a return date for round trip.')),
      );
      return;
    }
    if (_selectedClass == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a flight class.')),
      );
      return;
    }

    Map<String, dynamic> searchCriteria = {
      'tripType': _selectedTripType.toString().split('.').last,
      'from': _fromController.text,
      'to': _toController.text,
      // Date formatting without intl package
      'departureDate': _departureDate != null ? _departureDate!.toIso8601String().substring(0, 10) : null,
      'returnDate': _returnDate != null && _selectedTripType == TripType.roundTrip
          ? _returnDate!.toIso8601String().substring(0,10)
          : null,
      'class': _selectedClass,
      'passengers': _passengerCount,
    };

    print('Search Criteria: $searchCriteria');

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Searching for flights...'),
        backgroundColor: AppColors.primaryGreen,
        duration: const Duration(seconds: 1),
      ),
    );

    Future.delayed(const Duration(milliseconds: 1200), () {
      Navigator.pushNamed(
        context,
        '/flightresult',
        arguments: searchCriteria,
      );
    });
  }


  @override
  Widget build(BuildContext context) {
    // Get screen dimensions
    final screenSize = MediaQuery.of(context).size;
    final screenWidth = screenSize.width;
    final screenHeight = screenSize.height;

    bool isRoundTrip = _selectedTripType == TripType.roundTrip;

    // Define responsive padding and spacing
    final double horizontalPadding = screenWidth * 0.04; // 4% of screen width
    final double verticalPadding = screenHeight * 0.02; // 2% of screen height
    final double sectionSpacing = screenHeight * 0.025; // Spacing between sections
    final double fieldSpacing = screenWidth * 0.04; // Spacing between fields in a row
    final double buttonVerticalPadding = screenHeight * 0.018;
    final double buttonHorizontalPadding = screenWidth * 0.15;
    final double appBarFontSize = screenWidth * 0.05;
    final double sectionTitleFontSize = screenWidth * 0.04;
    final double textFieldFontSize = screenWidth * 0.038;
    final double toggleButtonMinWidth = (screenWidth - (horizontalPadding * 2) - (fieldSpacing * 2)) / 3; // For 3 toggle buttons


    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 1,
        centerTitle: true,
        title: Text(
          'Flight Search',
          style: TextStyle(
            color: AppColors.darkText,
            fontFamily: 'Inter',
            fontSize: appBarFontSize.clamp(18, 22), // Clamp font size for readability
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          // Use responsive padding
          padding: EdgeInsets.symmetric(horizontal: horizontalPadding, vertical: verticalPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(child: _buildTripTypeToggleButtons(toggleButtonMinWidth, screenHeight * 0.05)),
              SizedBox(height: sectionSpacing),

              _buildSectionTitle('From', sectionTitleFontSize),
              _buildLocationTextField(_fromController, 'Enter departure city or airport', textFieldFontSize),
              SizedBox(height: sectionSpacing),

              _buildSectionTitle('To', sectionTitleFontSize),
              _buildLocationTextField(_toController, 'Enter destination city or airport', textFieldFontSize),
              SizedBox(height: sectionSpacing),

              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildSectionTitle('Departure Date', sectionTitleFontSize),
                        _buildDateField(
                          context,
                          'Select Date',
                          _departureDate,
                              () => _selectDate(context, true),
                          textFieldFontSize,
                        ),
                      ],
                    ),
                  ),
                  if (isRoundTrip) SizedBox(width: fieldSpacing), // Responsive spacing
                  if (isRoundTrip)
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildSectionTitle('Return Date', sectionTitleFontSize),
                          _buildDateField(
                            context,
                            'Select Date',
                            _returnDate,
                                () => _selectDate(context, false),
                            textFieldFontSize,
                            enabled: _departureDate != null,
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              SizedBox(height: sectionSpacing),

              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildSectionTitle('Class', sectionTitleFontSize),
                        _buildClassDropdown(textFieldFontSize),
                      ],
                    ),
                  ),
                  SizedBox(width: fieldSpacing), // Responsive spacing
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildSectionTitle('Passengers', sectionTitleFontSize),
                        _buildPassengerDropdown(textFieldFontSize),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: sectionSpacing * 1.5),
              Center(
                child: ElevatedButton(
                  onPressed: _handleSearch,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(screenWidth * 0.03), // Responsive border radius
                    ),
                    padding: EdgeInsets.symmetric(
                        horizontal: buttonHorizontalPadding, vertical: buttonVerticalPadding),
                    textStyle: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: (textFieldFontSize * 1.1).clamp(16, 20), // Slightly larger than text fields
                        fontWeight: FontWeight.bold),
                  ),
                  child: const Text('Search Flights', style: TextStyle(color: AppColors.white, fontFamily: 'Inter')),
                ),
              ),
              SizedBox(height: verticalPadding), // Bottom padding
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, double fontSize) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).size.height * 0.01), // Responsive bottom padding
      child: Text(
        title,
        style: TextStyle(
          color: AppColors.darkText,
          fontFamily: 'Inter',
          fontSize: fontSize,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildTripTypeToggleButtons(double minWidth, double minHeight) {
    final screenWidth = MediaQuery.of(context).size.width;
    // Ensure text and icon can fit, adjust padding if necessary or use FittedBox for text.
    final double iconSize = screenWidth * 0.045;
    final double textSize = screenWidth * 0.032;
    final double horizontalPaddingToggle = screenWidth * 0.015;


    return ToggleButtons(
      isSelected: [
        _selectedTripType == TripType.oneWay,
        _selectedTripType == TripType.roundTrip,
        _selectedTripType == TripType.multiCity,
      ],
      onPressed: (int index) {
        setState(() {
          _selectedTripType = TripType.values[index];
          if (_selectedTripType == TripType.oneWay || _selectedTripType == TripType.multiCity) {
            _returnDate = null;
          }
        });
      },
      borderRadius: BorderRadius.circular(screenWidth * 0.02), // Responsive border radius
      selectedBorderColor: AppColors.primaryGreen,
      selectedColor: AppColors.white,
      fillColor: AppColors.primaryGreen,
      color: AppColors.primaryGreen,
      splashColor: AppColors.primaryGreen.withOpacity(0.12),
      constraints: BoxConstraints(minWidth: minWidth, minHeight: minHeight),
      children: <Widget>[
        Padding(
          padding: EdgeInsets.symmetric(horizontal: horizontalPaddingToggle),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.flight_takeoff, size: iconSize),
              SizedBox(width: screenWidth * 0.01),
              Text('One Way', style: TextStyle(fontFamily: 'Inter', fontSize: textSize))
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: horizontalPaddingToggle),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.compare_arrows, size: iconSize),
              SizedBox(width: screenWidth * 0.01),
              Text('Round Trip', style: TextStyle(fontFamily: 'Inter', fontSize: textSize))
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: horizontalPaddingToggle),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.multiple_stop, size: iconSize),
              SizedBox(width: screenWidth * 0.01),
              Text('Multi-city', style: TextStyle(fontFamily: 'Inter', fontSize: textSize))
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLocationTextField(TextEditingController controller, String hintText, double fontSize) {
    final screenWidth = MediaQuery.of(context).size.width;
    final double borderRadius = screenWidth * 0.03;
    final double contentPaddingHorizontal = screenWidth * 0.04;
    final double contentPaddingVertical = MediaQuery.of(context).size.height * 0.017;


    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: AppColors.lightText,
          fontFamily: 'Inter',
          fontSize: fontSize,
        ),
        filled: true,
        fillColor: AppColors.textFieldBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          borderSide: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: contentPaddingHorizontal, vertical: contentPaddingVertical),
        suffixIcon: controller.text.isNotEmpty
            ? IconButton(
          icon: Icon(Icons.clear, color: AppColors.lightText, size: fontSize * 1.2),
          onPressed: () {
            controller.clear();
            setState(() {});
          },
        )
            : null,
      ),
      style: TextStyle(
        color: AppColors.darkText,
        fontFamily: 'Inter',
        fontSize: fontSize,
      ),
      onChanged: (text) {
        setState(() {});
      },
    );
  }

  Widget _buildDateField(BuildContext context, String hintText, DateTime? date, VoidCallback onTap, double fontSize, {bool enabled = true}) {
    final screenWidth = MediaQuery.of(context).size.width;
    final double borderRadius = screenWidth * 0.03;
    final double contentPaddingHorizontal = screenWidth * 0.04;
    final double contentPaddingVertical = MediaQuery.of(context).size.height * 0.017;
    final double iconSize = fontSize * 1.1;

    // Date display without intl package
    String displayText = date != null
        ? "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}"
        : hintText;
    Color textColor = date != null ? AppColors.darkText : AppColors.lightText;
    if (!enabled) {
      textColor = AppColors.disabledColor;
      displayText = 'Select Date';
    }

    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(borderRadius),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: contentPaddingHorizontal, vertical: contentPaddingVertical),
        decoration: BoxDecoration(
            color: enabled ? AppColors.textFieldBackground : AppColors.textFieldBackground.withOpacity(0.5),
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(
                color: enabled ? Colors.transparent : AppColors.disabledColor.withOpacity(0.3)
            )
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              displayText,
              style: TextStyle(
                color: textColor,
                fontFamily: 'Inter',
                fontSize: fontSize,
                fontWeight: date != null ? FontWeight.w500 : FontWeight.normal,
              ),
            ),
            Icon(
              Icons.calendar_today,
              color: enabled ? AppColors.primaryGreen : AppColors.disabledColor,
              size: iconSize,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildClassDropdown(double fontSize) {
    final screenWidth = MediaQuery.of(context).size.width;
    final double borderRadius = screenWidth * 0.03;
    final double contentPaddingHorizontal = screenWidth * 0.04;
    final double contentPaddingVertical = MediaQuery.of(context).size.height * 0.017;


    return DropdownButtonFormField<String>(
      decoration: InputDecoration(
        filled: true,
        fillColor: AppColors.textFieldBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          borderSide: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: contentPaddingHorizontal, vertical: contentPaddingVertical -2), // Adjusted for DropdownButtonFormField intrinsic padding
      ),
      hint: Text('Select Class', style: TextStyle(color: AppColors.lightText, fontFamily: 'Inter', fontSize: fontSize)),
      value: _selectedClass,
      icon: Icon(Icons.arrow_drop_down, color: AppColors.primaryGreen, size: fontSize * 1.3),
      style: TextStyle(color: AppColors.darkText, fontFamily: 'Inter', fontSize: fontSize),
      isExpanded: true,
      items: _flightClasses.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value, style: TextStyle(fontFamily: 'Inter', fontSize: fontSize)),
        );
      }).toList(),
      onChanged: (String? newValue) {
        setState(() {
          _selectedClass = newValue;
        });
      },
    );
  }

  Widget _buildPassengerDropdown(double fontSize) {
    final screenWidth = MediaQuery.of(context).size.width;
    final double borderRadius = screenWidth * 0.03;
    final double contentPaddingHorizontal = screenWidth * 0.04;
    final double contentPaddingVertical = MediaQuery.of(context).size.height * 0.017;

    return DropdownButtonFormField<int>(
      decoration: InputDecoration(
        filled: true,
        fillColor: AppColors.textFieldBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          borderSide: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: contentPaddingHorizontal, vertical: contentPaddingVertical -2), // Adjusted for DropdownButtonFormField
      ),
      hint: Text('Count', style: TextStyle(color: AppColors.lightText, fontFamily: 'Inter', fontSize: fontSize)),
      value: _passengerCount,
      icon: Icon(Icons.arrow_drop_down, color: AppColors.primaryGreen, size: fontSize * 1.3),
      style: TextStyle(color: AppColors.darkText, fontFamily: 'Inter', fontSize: fontSize),
      isExpanded: true,
      items: _passengerNumbers.map<DropdownMenuItem<int>>((int value) {
        return DropdownMenuItem<int>(
          value: value,
          child: Text(value.toString(), style: TextStyle(fontFamily: 'Inter', fontSize: fontSize)),
        );
      }).toList(),
      onChanged: (int? newValue) {
        if (newValue != null) {
          setState(() {
            _passengerCount = newValue;
          });
        }
      },
    );
  }
}