import 'package:flutter/material.dart';

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends State<MyBookingsScreen> {
  int _selectedTab = 0; // 0 for Upcoming, 1 for Past, 2 for Cancelled
  int _bottomNavIndex = 1; // For BottomNavigationBar, 1 for "My Bookings"

  // --- Theme Colors (Consider moving to a shared theme file) ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32); // Example from HomeWidget
  static const Color _kWhiteColor = Colors.white;
  static const Color _kLightTextColor = Color(0xFF757575); // Example from HomeWidget
  static const Color _kDarkTextColor = Color(0xFF1C1B1F); // Example from HomeWidget


  void _onBottomNavItemTapped(int index) {
    if (_bottomNavIndex == index) {
      // If tapping the current active item, do nothing or refresh content
      if (index == 1) print("My Bookings tab re-selected");
      return;
    }

    setState(() {
      _bottomNavIndex = index;
    });

    switch (index) {
      case 0: // Dashboard
      // Navigate to Dashboard and remove other screens from stack
        Navigator.pushNamedAndRemoveUntil(context, '/dashboard', (Route<dynamic> route) => false);
        break;
      case 1: // My Bookings (Current Screen)
      // Already on this screen, or if navigated from elsewhere, ensure it's the target.
      // If MyBookingsScreen can be pushed multiple times, consider specific logic.
      // For now, if it's already the current screen, _bottomNavIndex is updated, nothing else.
      // If it was somehow reached without being the primary route for this index,
      // you might want Navigator.pushReplacementNamed(context, '/mybookings');
        break;
      case 2: // Profile
        Navigator.pushNamed(context, '/profile');
        break;
    }
  }


  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kWhiteColor,
        foregroundColor: _kDarkTextColor,
        elevation: 0,
        title: const Text(
          'My Bookings',
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.bold,
            color: _kDarkTextColor, // Use consistent text color
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.grey[600]), // Consistent icon color
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            } else {
              // If cannot pop, go to a default screen like dashboard
              Navigator.pushNamedAndRemoveUntil(context, '/dashboard', (Route<dynamic> route) => false);
            }
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05, vertical: 8.0), // Added vertical padding
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(child: _buildTabButton(context, 'Upcoming', 0, screenWidth)),
                  Expanded(child: _buildTabButton(context, 'Past', 1, screenWidth)),
                  Expanded(child: _buildTabButton(context, 'Cancelled', 2, screenWidth)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16.0),
          Expanded(
            child: _buildBookingsList(context, _selectedTab, screenWidth),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _bottomNavIndex,
        onTap: _onBottomNavItemTapped,
        backgroundColor: _kWhiteColor,
        selectedItemColor: _kPrimaryGreen, // Use consistent selected color
        unselectedItemColor: _kLightTextColor, // Use consistent unselected color
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true, // Good practice
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_rounded), // Consistent icon
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.work_history_rounded), // Consistent icon
            label: 'My Bookings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_rounded), // Consistent icon
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(BuildContext context, String title, int index, double screenWidth) {
    final isSelected = _selectedTab == index;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedTab = index;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12.0),
        decoration: BoxDecoration(
          color: isSelected ? _kWhiteColor : Colors.transparent, // Use consistent color
          borderRadius: BorderRadius.circular(8.0),
          boxShadow: isSelected ? [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 1,
              blurRadius: 3,
              offset: const Offset(0, 1),
            )
          ] : [],
        ),
        child: Center(
          child: Text(
            title,
            style: TextStyle(
              fontSize: screenWidth * 0.038, // Adjusted for potentially smaller buttons
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? _kPrimaryGreen : _kDarkTextColor.withOpacity(0.7), // Consistent colors
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBookingsList(BuildContext context, int tabIndex, double screenWidth) {
    List<Map<String, String>> bookingsData = [];

    // Data population logic remains the same
    if (tabIndex == 0) { // Upcoming
      bookingsData = [
        {'type': 'Flight', 'details': 'Flight to New York (Departure: 05 Oct, 2024)', 'date': 'Oct 5, 2024'},
        {'type': 'Hotel', 'details': 'Hotel Reservation: Hilton Grand (Check-in: 08 Oct, 2024)', 'date': 'Oct 8, 2024'},
        {'type': 'Transport', 'details': 'Uber - JFK to Manhattan (05 Oct, 2024)', 'date': 'Oct 5, 2024'},
        {'type': 'Flight', 'details': 'Flight to Los Angeles (Departure: 15 Nov, 2024)', 'date': 'Nov 15, 2024'},
      ];
    } else if (tabIndex == 1) { // Past
      bookingsData = [
        {'type': 'Flight', 'details': 'Flight to London (Completed: 10 Aug, 2023)', 'date': 'Aug 10, 2023'},
        {'type': 'Hotel', 'details': 'Hotel Reservation: Hyatt Regency (Completed: 12 Aug, 2023)', 'date': 'Aug 12, 2023'},
      ];
    } else if (tabIndex == 2) { // Cancelled
      bookingsData = [
        {'type': 'Flight', 'details': 'Flight to Dubai (Cancelled: 01 Sep, 2024)', 'date': 'Sep 1, 2024'},
        {'type': 'Hotel', 'details': 'Hotel Reservation: Atlantis The Palm (Cancelled: 01 Sep, 2024)', 'date': 'Sep 1, 2024'},
      ];
    }

    if (bookingsData.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.info_outline, size: screenWidth * 0.15, color: Colors.grey[400]),
            const SizedBox(height: 16.0),
            Text(
              'No ${['Upcoming', 'Past', 'Cancelled'][tabIndex]} bookings found.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: screenWidth * 0.045,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
      itemCount: bookingsData.length,
      itemBuilder: (context, index) {
        final booking = bookingsData[index];
        return Card(
          elevation: 2, // Slightly more elevation for better visual separation
          margin: const EdgeInsets.only(bottom: 12.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0), // More rounded corners
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(12.0), // Match card shape
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Tapped on: ${booking['details']}'),
                  duration: const Duration(seconds: 1),
                ),
              );
              // Consider navigating to a booking detail screen:
              // Navigator.pushNamed(context, '/booking_details', arguments: booking);
            },
            child: Padding(
              padding: EdgeInsets.all(screenWidth * 0.04),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        _getBookingIcon(booking['type']!),
                        color: _kPrimaryGreen, // Use consistent icon color
                        size: screenWidth * 0.055, // Slightly larger icon
                      ),
                      SizedBox(width: screenWidth * 0.03),
                      Expanded(
                        child: Text(
                          booking['details']!,
                          style: TextStyle(
                            fontSize: screenWidth * 0.042,
                            fontWeight: FontWeight.w600,
                            color: _kDarkTextColor, // Consistent text color
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8.0),
                  Text(
                    'Date: ${booking['date']}',
                    style: TextStyle(
                      fontSize: screenWidth * 0.035,
                      color: _kLightTextColor, // Consistent text color
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  IconData _getBookingIcon(String type) {
    // This logic remains the same
    switch (type) {
      case 'Flight':
        return Icons.flight_rounded; // Using rounded icons for consistency
      case 'Hotel':
        return Icons.hotel_rounded;
      case 'Transport':
        return Icons.directions_car_rounded;
      default:
        return Icons.event_rounded;
    }
  }
}