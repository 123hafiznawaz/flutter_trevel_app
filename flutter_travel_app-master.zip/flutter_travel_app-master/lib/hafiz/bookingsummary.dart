import 'package:flutter/material.dart';

// Consider renaming to booking_summary_widget.dart and BookingSummaryWidget

class Booking_summaryWidget extends StatefulWidget {
  const Booking_summaryWidget({super.key}); // Added super.key

  @override
  _Booking_summaryWidgetState createState() => _Booking_summaryWidgetState();
}

class _Booking_summaryWidgetState extends State<Booking_summaryWidget> {
  // --- Theme Colors ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32); // Deep green
  static const Color _kWhiteColor = Colors.white;
  static const Color _kDarkTextColor = Color(0xFF1C1B1F); // Main text color
  static const Color _kLightTextColor = Color(0xFF757575); // Secondary text or icons
  static const Color _kDividerColor = Color(0xFFE0E0E0); // Light gray for dividers
  static const Color _kCardBackgroundColor = Color(0xFFF9F9F9); // Very light gray for cards

  // --- Sample Data (Replace with actual data) ---
  final Map<String, dynamic> _bookingDetails = {
    'serviceName': 'Luxury Sedan Transfer',
    'transportType': 'Airport Shuttle',
    'pickupLocation': 'JFK Airport, Terminal 4',
    'dropoffLocation': 'Grand Hyatt Hotel, E 42nd St',
    'date': 'October 26, 2023',
    'time': '3:00 PM',
  };

  final Map<String, dynamic> _travelerInfo = {
    'name': 'John Doe',
    'email': 'john.doe@example.com',
    'phone': '(123) 456-7890',
  };

  final Map<String, dynamic> _costDetails = {
    'baseFare': 75.00,
    'taxesAndFees': 12.50,
    'discount': 5.00,
    'totalCost': 82.50, // (baseFare + taxesAndFees) - discount
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kWhiteColor,
        elevation: 1.0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _kPrimaryGreen),
          onPressed: () {
            if (Navigator.canPop(context)) Navigator.pop(context);
          },
          tooltip: 'Back',
        ),
        title: const Text(
          'Booking Summary',
          style: TextStyle(
            color: _kPrimaryGreen,
            fontWeight: FontWeight.bold,
            fontFamily: 'Inter',
            fontSize: 22,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // --- Selected Service Section ---
            _buildSectionTitle('Selected Service'),
            _buildServiceDetailsCard(),
            const SizedBox(height: 24),

            // --- Traveler Information Section ---
            _buildSectionTitle('Traveler Information'),
            _buildTravelerInfoCard(),
            const SizedBox(height: 24),

            // --- Cost Breakdown Section ---
            _buildSectionTitle('Cost Details'),
            _buildCostDetailsCard(),
            const SizedBox(height: 32), // Extra space before the button
          ],
        ),
      ),
      bottomNavigationBar: _buildProceedButton(context), // Pass context here
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0, top: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          color: _kDarkTextColor,
          fontSize: 20,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter',
        ),
      ),
    );
  }

  Widget _buildServiceDetailsCard() {
    return Card(
      elevation: 2.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      color: _kCardBackgroundColor,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              _bookingDetails['serviceName'] as String,
              style: const TextStyle(
                color: _kPrimaryGreen,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 12),
            _buildDetailRow(
                icon: Icons.directions_car,
                label: 'Type',
                value: _bookingDetails['transportType'] as String),
            _buildDetailRow(
                icon: Icons.location_on_outlined,
                label: 'Pickup',
                value: _bookingDetails['pickupLocation'] as String),
            _buildDetailRow(
                icon: Icons.location_on,
                label: 'Drop-off',
                value: _bookingDetails['dropoffLocation'] as String),
            _buildDetailRow(
                icon: Icons.calendar_today,
                label: 'Date',
                value: _bookingDetails['date'] as String),
            _buildDetailRow(
                icon: Icons.access_time,
                label: 'Time',
                value: _bookingDetails['time'] as String),
          ],
        ),
      ),
    );
  }

  Widget _buildTravelerInfoCard() {
    return Card(
      elevation: 2.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      color: _kCardBackgroundColor,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _buildDetailRow(
                icon: Icons.person,
                label: 'Name',
                value: _travelerInfo['name'] as String),
            _buildDetailRow(
                icon: Icons.email,
                label: 'Email',
                value: _travelerInfo['email'] as String),
            _buildDetailRow(
                icon: Icons.phone,
                label: 'Contact',
                value: _travelerInfo['phone'] as String),
          ],
        ),
      ),
    );
  }

  Widget _buildCostDetailsCard() {
    return Card(
      elevation: 2.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      color: _kCardBackgroundColor,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            _buildCostRow('Base Fare', _costDetails['baseFare'] as double),
            _buildCostRow('Taxes & Fees', _costDetails['taxesAndFees'] as double),
            if ((_costDetails['discount'] as double) > 0)
              _buildCostRow('Discount', -(_costDetails['discount'] as double), isDiscount: true),
            const Divider(height: 24, thickness: 1, color: _kDividerColor),
            _buildCostRow('Total Cost', _costDetails['totalCost'] as double, isTotal: true),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow({required IconData icon, required String label, required String value}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: _kPrimaryGreen, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: _kLightTextColor,
                    fontFamily: 'Inter',
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    color: _kDarkTextColor,
                    fontFamily: 'Inter',
                    fontSize: 16,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCostRow(String label, double amount, {bool isTotal = false, bool isDiscount = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(
              color: isTotal ? _kPrimaryGreen : _kDarkTextColor,
              fontFamily: 'Inter',
              fontSize: isTotal ? 18 : 16,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            '${isDiscount ? '-' : ''}\$${amount.abs().toStringAsFixed(2)}',
            style: TextStyle(
              color: isTotal ? _kPrimaryGreen : (isDiscount ? Colors.red.shade700 : _kDarkTextColor),
              fontFamily: 'Inter',
              fontSize: isTotal ? 18 : 16,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProceedButton(BuildContext context) { // Accept context as a parameter
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: _kWhiteColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 0,
            blurRadius: 5,
            offset: const Offset(0, -2), // Shadow on top
          ),
        ],
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: _kPrimaryGreen,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          minimumSize: const Size(double.infinity, 50),
        ),
        onPressed: () {
          // Navigate to the '/payment' route
          Navigator.pushNamed(context, '/payment');
        },
        child: const Text(
          'Proceed to Payment',
          style: TextStyle(
            color: _kWhiteColor,
            fontFamily: 'Inter',
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}