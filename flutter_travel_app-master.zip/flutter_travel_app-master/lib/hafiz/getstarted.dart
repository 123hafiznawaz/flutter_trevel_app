import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Required for SystemChrome

class TutorialScreen extends StatefulWidget {
  const TutorialScreen({super.key});

  @override
  _TutorialScreenState createState() => _TutorialScreenState();
}

class _TutorialScreenState extends State<TutorialScreen> {
  int _currentPage = 0;
  final PageController _pageController = PageController(initialPage: 0);

  final List<Map<String, dynamic>> _tutorialPages = [
    {
      'title': 'Explore the World with Ease',
      'description':
      'Discover breathtaking destinations, plan your dream trips, and unlock a world of travel possibilities right at your fingertips. Our app makes global exploration simple and enjoyable.',
      'imagePath': 'assets/images/onboarding1.jpg',
    },
    {
      'title': 'Get AI-Powered Travel Suggestions Tailored for You',
      'description':
      'Experience personalized travel recommendations powered by advanced AI. From hidden gems to popular landmarks, we suggest the perfect places based on your preferences and past adventures.',
      'imagePath': 'assets/images/onboarding2.png',
    },
    {
      'title': 'Book Flights, Hotels, and Rides in One App',
      'description':
      'Simplify your travel bookings! Secure flights, reserve cozy hotels, and arrange convenient rides all within a single, intuitive application. Plan your entire journey seamlessly.',
      'imagePath': 'assets/images/onboarding3.jpg',
    },
  ];

  @override
  void initState() {
    super.initState();
    // Optional: Make the onboarding screen immersive for a cleaner look.
    // SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    _pageController.dispose();
    // Optional: Restore system UI when leaving the screen if you made it immersive.
    // SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions for responsive layout
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    // Define responsive factors (adjust these values as needed for your design)
    final double titleFontSize = screenWidth * 0.065; // e.g., 6.5% of screen width
    final double descriptionFontSize = screenWidth * 0.04; // e.g., 4% of screen width
    final double buttonFontSize = screenWidth * 0.045;
    final double pageVerticalPadding = screenHeight * 0.02; // Padding for the page content itself
    final double bottomControlsVerticalPadding = screenHeight * 0.03;
    final double horizontalPadding = screenWidth * 0.05; // General horizontal padding
    final double dotIndicatorSpacing = screenHeight * 0.025;
    final double buttonHeight = screenHeight * 0.065;
    final double imageMaxHeight = screenHeight * 0.43; // Max height for the image area

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              itemCount: _tutorialPages.length,
              onPageChanged: (int page) {
                setState(() {
                  _currentPage = page;
                });
              },
              itemBuilder: (context, index) {
                return _buildTutorialPage(
                  title: _tutorialPages[index]['title'],
                  description: _tutorialPages[index]['description'],
                  imagePath: _tutorialPages[index]['imagePath'],
                  titleFontSize: titleFontSize,
                  descriptionFontSize: descriptionFontSize,
                  imageMaxHeight: imageMaxHeight,
                  pageHorizontalPadding: horizontalPadding,
                  pageVerticalPadding: pageVerticalPadding,
                  screenHeight: screenHeight,
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(
                horizontal: horizontalPadding, vertical: bottomControlsVerticalPadding),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    _tutorialPages.length,
                        (index) => _buildDot(index, context, screenWidth),
                  ),
                ),
                SizedBox(height: dotIndicatorSpacing),
                SizedBox(
                  width: double.infinity,
                  height: buttonHeight,
                  child: ElevatedButton(
                    onPressed: () {
                      if (_currentPage < _tutorialPages.length - 1) {
                        _pageController.nextPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeIn,
                        );
                      } else {
                        // Last page: Navigate to login or home
                        Navigator.pushReplacementNamed(context, '/login');
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(screenWidth * 0.03), // Responsive border radius
                      ),
                      padding: EdgeInsets.zero, // Let SizedBox control height
                    ),
                    child: Text(
                      _currentPage == _tutorialPages.length - 1
                          ? 'Get Started'
                          : 'Next',
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Inter',
                        fontSize: buttonFontSize.clamp(16.0, 20.0), // Clamp font size
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // SafeArea for bottom gesture navigation bar if not fully immersive
          SafeArea(
            top: false, // Only apply to bottom
            bottom: true,
            child: SizedBox(height: screenHeight * 0.01), // Minimal padding for gesture bar
          ),
        ],
      ),
    );
  }

  Widget _buildTutorialPage({
    required String title,
    required String description,
    required String imagePath,
    required double titleFontSize,
    required double descriptionFontSize,
    required double imageMaxHeight,
    required double pageHorizontalPadding, // Renamed for clarity
    required double pageVerticalPadding,   // Added for page content
    required double screenHeight,
  }) {
    return Padding(
      // Added padding property for the overall page content area
      padding: EdgeInsets.symmetric(
          horizontal: pageHorizontalPadding, vertical: pageVerticalPadding),
      // If you are using SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      // you might not need a SafeArea here. Otherwise, it can be useful,
      // especially if content could go under the status bar.
      // child: SafeArea(
      //   top: true, // Apply padding only to the top if needed for status bar
      //   bottom: false, // Already handled by bottom SafeArea in Scaffold
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center, // Center the content vertically within the page
        children: [
          Flexible(
            flex: 6, // Allocates more space to the image container
            child: Padding(
              // Padding within the image's flexible container (can be 0 if page padding is enough)
              padding: EdgeInsets.symmetric(vertical: screenHeight * 0.01),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: imageMaxHeight, // Max height for the image
                ),
                child: Image.asset(
                  imagePath,
                  fit: BoxFit.contain, // Ensures the whole image is visible
                  errorBuilder: (context, error, stackTrace) {
                    print("Error loading image: $imagePath, $error");
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Center(
                        child: Icon(Icons.broken_image_rounded,
                            size: 80, color: Colors.grey),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
          SizedBox(height: screenHeight * 0.03), // Space between image and text block
          Flexible(
            flex: 4, // Allocates less space to the text container
            child: Padding(
              // Padding for the text block (can adjust or use pageHorizontalPadding)
              padding: EdgeInsets.symmetric(horizontal: pageHorizontalPadding * 0.2), // Slightly less than page padding
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start, // Align text to the top of its space
                children: [
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: const Color.fromRGBO(28, 27, 31, 1),
                      fontFamily: 'Inter', // Ensure 'Inter' font is in pubspec.yaml and assets
                      fontSize: titleFontSize.clamp(20.0, 30.0), // Clamp font size
                      fontWeight: FontWeight.bold,
                      height: 1.25, // Line height
                    ),
                  ),
                  SizedBox(height: screenHeight * 0.015), // Space between title and description
                  Text(
                    description,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.grey.shade700,
                      fontFamily: 'Inter',
                      fontSize: descriptionFontSize.clamp(14.0, 18.0), // Clamp font size
                      height: 1.5, // Line height
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
        // ), // End of SafeArea if used
      ),
    );
  }

  Widget _buildDot(int index, BuildContext context, double screenWidth) {
    double dotHeight = screenWidth * 0.02;    // e.g., 2% of screen width
    double activeDotWidth = screenWidth * 0.05; // e.g., 5% of screen width
    double dotMargin = screenWidth * 0.01;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      margin: EdgeInsets.symmetric(horizontal: dotMargin),
      height: dotHeight.clamp(6.0, 10.0), // Min 6px, Max 10px height
      width: (_currentPage == index ? activeDotWidth : dotHeight).clamp(6.0, 24.0), // Min 6px, Max 24px width
      decoration: BoxDecoration(
        color: _currentPage == index
            ? Colors.green.shade700
            : Colors.grey.shade300,
        borderRadius: BorderRadius.circular(dotHeight / 2), // Make it circular/pill-shaped
      ),
    );
  }
}