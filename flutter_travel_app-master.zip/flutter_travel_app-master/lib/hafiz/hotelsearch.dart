import 'package:flutter/material.dart';

class Hotel_searchWidget extends StatefulWidget {
  @override
  _Hotel_searchWidgetState createState() => _Hotel_searchWidgetState();
}

class _Hotel_searchWidgetState extends State<Hotel_searchWidget> {
  @override
  Widget build(BuildContext context) {
    // Using MediaQuery for responsiveness
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // Define base font sizes and scale factors for a professional look
    final double baseFontSize = 14.0;
    final double headingFontSize = 28.0; // Slightly larger for main heading
    final double subHeadingFontSize = 18.0;
    final double inputLabelFontSize = 14.0;
    final double inputTextFontSize = 16.0;
    final double buttonFontSize = 16.0;
    final double amenityIconSize = 20.0; // Size for amenity icons

    // Define responsive padding and spacing
    final double horizontalPadding = screenWidth * 0.05; // 5% of screen width
    final double verticalSpacingLarge = screenHeight * 0.03; // Large vertical spacing
    final double verticalSpacingMedium = screenHeight * 0.02; // Medium vertical spacing
    final double verticalSpacingSmall = screenHeight * 0.01; // Small vertical spacing
    final double inputFieldVerticalPadding = 12.0;
    final double inputFieldHorizontalPadding = 16.0;

    return Scaffold(
      backgroundColor: Colors.white, // Overall screen background
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0, // No shadow for a cleaner look
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.green.shade800, size: 20),
          onPressed: () {
            // Handle back button press
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            // Using standard Flutter Icons for connectivity
            Icon(Icons.wifi, color: Colors.green.shade800, size: 18),
            SizedBox(width: 6),
            Icon(Icons.signal_cellular_alt, color: Colors.green.shade800, size: 18),
            SizedBox(width: 6),
            Icon(Icons.battery_full, color: Colors.green.shade800, size: 18),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: verticalSpacingLarge),
            Text(
              'Hotel Search',
              style: TextStyle(
                color: Colors.green.shade900,
                fontFamily: 'Inter',
                fontSize: headingFontSize,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: verticalSpacingLarge),

            // Destination Input
            Text(
              'Destination',
              style: TextStyle(
                color: Colors.green.shade800,
                fontFamily: 'Inter',
                fontSize: subHeadingFontSize,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: verticalSpacingSmall),
            _buildInputField(
              hintText: 'Enter city or hotel name',
              fontSize: inputTextFontSize,
              verticalPadding: inputFieldVerticalPadding,
              horizontalPadding: inputFieldHorizontalPadding,
            ),
            SizedBox(height: verticalSpacingMedium * 1.5),

            // Check-in & Check-out Dates
            Text(
              'Check-in & Check-out Dates',
              style: TextStyle(
                color: Colors.green.shade800,
                fontFamily: 'Inter',
                fontSize: subHeadingFontSize,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: verticalSpacingSmall),
            Row(
              children: [
                Expanded(
                  child: _buildDateSelection(
                    label: 'Start',
                    date: 'Tue, Oct 24',
                    fontSize: inputTextFontSize,
                  ),
                ),
                SizedBox(width: horizontalPadding), // Spacing between date fields
                Expanded(
                  child: _buildDateSelection(
                    label: 'End',
                    date: 'Wed, Oct 25',
                    fontSize: inputTextFontSize,
                  ),
                ),
              ],
            ),
            SizedBox(height: verticalSpacingMedium * 1.5),

            // Guests & Rooms
            Text(
              'Guests & Rooms',
              style: TextStyle(
                color: Colors.green.shade800,
                fontFamily: 'Inter',
                fontSize: subHeadingFontSize,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: verticalSpacingSmall),
            _buildInputField(
              hintText: 'Select number of guests and rooms',
              fontSize: inputTextFontSize,
              verticalPadding: inputFieldVerticalPadding,
              horizontalPadding: inputFieldHorizontalPadding,
              suffixIcon: Icons.arrow_drop_down, // Example icon
            ),
            SizedBox(height: verticalSpacingMedium * 1.5),

            // Filters
            Text(
              'Filters',
              style: TextStyle(
                color: Colors.green.shade800,
                fontFamily: 'Inter',
                fontSize: subHeadingFontSize,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: verticalSpacingSmall),
            Column(
              children: [
                _buildAmenityRow(Icons.pool, 'Pool', amenityIconSize),
                _buildAmenityRow(Icons.wifi, 'Wi-Fi', amenityIconSize),
                _buildAmenityRow(Icons.pets, 'Pet Friendly', amenityIconSize),
                _buildAmenityRow(Icons.local_parking, 'Parking', amenityIconSize),
                _buildAmenityRow(Icons.restaurant, 'Restaurant', amenityIconSize),
              ],
            ),
            SizedBox(height: verticalSpacingLarge * 2), // Extra space before bottom button
          ],
        ),
      ),
      bottomNavigationBar: Container(
        color: Colors.white,
        padding: EdgeInsets.fromLTRB(horizontalPadding, verticalSpacingMedium, horizontalPadding, screenHeight * 0.02),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              onPressed: () {
                // Navigate to the hotel results screen
                Navigator.pushNamed(context, '/hotelresult');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade800, // Dark green for the button
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                minimumSize: Size(double.infinity, screenHeight * 0.06), // Responsive button height
              ),
              child: Text(
                'Search',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Inter',
                  fontSize: buttonFontSize,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.01),
            Container(
              width: screenWidth * 0.3, // Responsive width for the home indicator
              height: 4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: Colors.green.shade900, // Darker green for indicator
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Helper method to build a styled input field
  Widget _buildInputField({
    required String hintText,
    required double fontSize,
    required double verticalPadding,
    required double horizontalPadding,
    IconData? suffixIcon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.green.shade50, // Light green background
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.shade200, width: 1), // Subtle border
      ),
      padding: EdgeInsets.symmetric(
        horizontal: horizontalPadding,
        vertical: verticalPadding,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              hintText,
              style: TextStyle(
                color: Colors.green.shade400, // Lighter green for hint text
                fontFamily: 'Inter',
                fontSize: fontSize,
              ),
            ),
          ),
          if (suffixIcon != null)
            Icon(
              suffixIcon,
              color: Colors.green.shade600, // Green icon
              size: 20,
            ),
        ],
      ),
    );
  }

  /// Helper method to build date selection fields
  Widget _buildDateSelection({
    required String label,
    required String date,
    required double fontSize,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.shade200, width: 1),
      ),
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.green.shade400,
              fontFamily: 'Inter',
              fontSize: 12, // Smaller label for date
            ),
          ),
          SizedBox(height: 4),
          Text(
            date,
            style: TextStyle(
              color: Colors.green.shade800,
              fontFamily: 'Inter',
              fontSize: fontSize,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  /// Helper method to build an amenity row with an icon and text
  Widget _buildAmenityRow(IconData icon, String label, double iconSize) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: Colors.green.shade700, size: iconSize),
          SizedBox(width: 12),
          Text(
            label,
            style: TextStyle(
              color: Colors.green.shade800,
              fontFamily: 'Inter',
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}