import 'package:flutter/material.dart';

class SearchWidget extends StatefulWidget {
  const SearchWidget({super.key});

  @override
  _SearchWidgetState createState() => _SearchWidgetState();
}

class _SearchWidgetState extends State<SearchWidget> {
  // --- Theme Colors (Consider moving to a shared theme file) ---
  static const Color _kPrimaryGreen = Color(0xFF2E7D32); // Example primary green
  static const Color _kWhiteColor = Colors.white;
  static const Color _kDarkTextColor = Color.fromRGBO(28, 27, 31, 1);
  static const Color _kCardBackgroundColor = Color(0xFFE8F5E9); // Lighter green for cards
  static const Color _kCardIconColor = Color(0xFF1B5E20);     // Darker green for card icons/text
  static const Color _kCardShadowColor = Colors.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kWhiteColor,
      appBar: AppBar(
        backgroundColor: _kWhiteColor,
        elevation: 0,
        toolbarHeight: 60,
        titleSpacing: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.grey[600]),
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
            // else {
            //   // Optional: Fallback if cannot pop, e.g., navigate to dashboard
            //   Navigator.pushNamedAndRemoveUntil(context, '/dashboard', (Route<dynamic> route) => false);
            // }
          },
        ),
        title: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(
            'What would you like to search?',
            textAlign: TextAlign.left,
            style: TextStyle(
              color: _kDarkTextColor,
              fontFamily: 'Inter',
              fontSize: 26,
              fontWeight: FontWeight.bold,
              height: 1.25,
            ),
          ),
        ),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                children: [
                  const SizedBox(height: 24), // Spacing after title
                  Wrap(
                    spacing: 16.0,
                    runSpacing: 16.0,
                    alignment: WrapAlignment.center,
                    children: <Widget>[
                      _buildSearchCategoryCard(
                        context,
                        Icons.flight_takeoff_rounded,
                        'Flights',
                            () => Navigator.pushNamed(context, '/flightsearch'),
                      ),
                      _buildSearchCategoryCard(
                        context,
                        Icons.hotel_rounded,
                        'Hotels',
                            () => Navigator.pushNamed(context, '/hotelsearch'),
                      ),
                      _buildSearchCategoryCard(
                        context,
                        Icons.directions_car_filled_rounded,
                        'Transport',
                            () => Navigator.pushNamed(context, '/transporttype'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // "Search Through Filter" Button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kPrimaryGreen,
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  elevation: 2,
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/searchfilter');
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    // Icon might be redundant if button text is clear
                    // Icon(Icons.filter_alt_rounded, size: 20, color: _kWhiteColor),
                    // SizedBox(width: 8),
                    Text(
                      'Search Through Filter',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Inter',
                        color: _kWhiteColor,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchCategoryCard(
      BuildContext context,
      IconData icon,
      String label,
      VoidCallback onTapAction, // Added VoidCallback for specific navigation
      ) {
    return InkWell(
      onTap: onTapAction, // Use the passed navigation action
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: MediaQuery.of(context).size.width / 2 - 24,
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _kCardBackgroundColor,
          boxShadow: [
            BoxShadow(
              color: _kCardShadowColor.withOpacity(0.15),
              spreadRadius: 1,
              blurRadius: 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(
              icon,
              size: 48,
              color: _kCardIconColor,
            ),
            const SizedBox(height: 12),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _kCardIconColor,
                fontFamily: 'Inter',
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}