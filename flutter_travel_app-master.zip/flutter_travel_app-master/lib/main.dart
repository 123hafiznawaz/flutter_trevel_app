import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:hafizmnawaz/hafiz/splash.dart';
import 'package:hafizmnawaz/hafiz/getstarted.dart';
import 'package:hafizmnawaz/hafiz/login.dart';
import 'package:hafizmnawaz/hafiz/signup.dart';
import 'package:hafizmnawaz/hafiz/dashboard.dart';
import 'package:hafizmnawaz/hafiz/search.dart';
import 'package:hafizmnawaz/hafiz/moresuggestions.dart';
import 'package:hafizmnawaz/hafiz/searchfilter.dart';
import 'package:hafizmnawaz/hafiz/flightsearch.dart';
import 'package:hafizmnawaz/hafiz/flightresult.dart';
import 'package:hafizmnawaz/hafiz/searchresult.dart';
import 'package:hafizmnawaz/hafiz/flightdetail.dart';
import 'package:hafizmnawaz/hafiz/hotelsearch.dart';
import 'package:hafizmnawaz/hafiz/hotelresult.dart';
import 'package:hafizmnawaz/hafiz/hoteldetail.dart';
import 'package:hafizmnawaz/hafiz/transporttype.dart';
import 'package:hafizmnawaz/hafiz/transportbooking.dart';
import 'package:hafizmnawaz/hafiz/bookingsummary.dart';
import 'package:hafizmnawaz/hafiz/mybookings.dart';
import 'package:hafizmnawaz/hafiz/payment.dart';
import 'package:hafizmnawaz/hafiz/profile.dart';
import 'package:hafizmnawaz/hafiz/tickets.dart';
import 'package:hafizmnawaz/hafiz/resetpassword.dart';


Future <void> main()async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) =>  SplashWidget(),
      '/getstarted': (context) =>  TutorialScreen(),
      '/login': (context) =>  LoginScreen(),
      '/resetpassword': (context) =>  ResetPasswordScreen(),
      '/signup': (context) =>  SignupWidget(),
      '/dashboard': (context) =>  HomeWidget(),
      '/search': (context) =>  SearchWidget(),
      '/moresuggestions': (context) =>  Aisuggestions(),
      '/searchfilter': (context) =>  SearchFilterWidget(),
      '/flightsearch': (context) =>  FlightSearchWidget(),
      '/flightresult': (context) =>  FlightResultsWidget(),
      '/searchresult': (context) =>  SearchResultsScreen(filters: {},),
      '/flightdetail': (context) =>  Flight_detailsWidget(),
      '/hotelsearch': (context) =>  Hotel_searchWidget(),
      '/hotelresult': (context) =>  HotelResultsWidget(),
      '/hoteldetail': (context) =>  Hotel_detailsWidget(),
      '/transporttype': (context) =>  TransportTypeWidget(),
      '/transportbooking': (context) =>  TransportBookingScreen(),
      '/bookingsummary': (context) =>  Booking_summaryWidget(),
      '/mybookings': (context) =>  MyBookingsScreen(),
      '/payment': (context) =>  PaymentScreen(),
      '/profile': (context) =>  ProfileScreen(),
      '/tickets': (context) =>  TicketWidget(),




    },
  ));
}